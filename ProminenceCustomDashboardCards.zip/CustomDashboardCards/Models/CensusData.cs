﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CustomDashboardCards.Models
{
    /*
     Subscriber ID		Member Name		DOB					
	Case ID 	Primary Case Manager	Plan Description	Source 	PCP	Admit date	facility	POS	DC date
									
	Notes	Up to 3000 characters							

     */

    //[Table("CensusData")]
    public class CensusData
    {
        //[Key]
        public int ID { get; set; }

        //[Required(ErrorMessage = "Required Subscriber ID")]
        public string SubscriberID { get; set; }
        //[Required(ErrorMessage = "Required Member Name")]
        public string MemberName { get; set; }
        //[Required(ErrorMessage = "Required Date Of Birth")]
        public string DOB { get; set; }
        public string CaseID { get; set; }

        public string PrimaryCaseManager { get; set; }
        public string PlanDesc { get; set; }

        public string Source { get; set; }

        public string PCP { get; set; }

        public DateTime AdmitDate { get; set; }

        public string Facility { get; set; }

        public string POS { get; set; }

        public DateTime DCDate { get; set; }

        public string Notes { get; set; }
    }
}