﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;
//using Microsoft.Extensions.Configuration;

namespace CustomDashboardCards.Models
{
    public class dal
    {

        public string ConnectionString { get; set; }

        public dal()
        {
            ConnectionString = ConfigurationManager.AppSettings["ConnectionString"];
        }


        public string GetCensusData()
        {

            string connString = ConnectionString;
            string sprocname = "prhp_Dashboard_GetCensusData";
            string jsonOutputParam = "@jsonOutput";

            using (SqlConnection conn = new SqlConnection(connString))
            {
                conn.Open();

                using (SqlCommand cmd = new SqlCommand(sprocname, conn))
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;

                    // Create output parameter. "-1" is used for nvarchar(max)
                    cmd.Parameters.Add(jsonOutputParam, SqlDbType.NVarChar, -1).Direction = ParameterDirection.Output;

                    // Execute the command
                    cmd.ExecuteNonQuery();

                    // Get the values
                    string json = cmd.Parameters[jsonOutputParam].Value.ToString();

                    return json;
                }
            }

        }

    }
}
