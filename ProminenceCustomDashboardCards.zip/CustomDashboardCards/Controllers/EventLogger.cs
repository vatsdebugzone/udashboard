﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Diagnostics;

namespace CustomDashboardCards.Controllers
{
    public class EventLogger
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}
        public void WriteMessage(string message, string ErrorType)
        {

            if (!EventLog.SourceExists("Trizetto .NET Custom Dashboard"))
            {
                EventLog.CreateEventSource("Trizetto .NET Custom Dashboard", "Application");
            }
            EventLog appLog = new System.Diagnostics.EventLog();

            appLog.Log = "Application";
            appLog.Source = "Trizetto .NET Custom Dashboard";

            switch (ErrorType.ToUpper())
            {
                case "ERROR":
                    appLog.WriteEntry(message, EventLogEntryType.Error, 200);
                    break;
                case "INFO":
                    appLog.WriteEntry(message, EventLogEntryType.Information, 201);
                    break;
                default:
                    appLog.WriteEntry(message, EventLogEntryType.Warning, 202);
                    break;
            }

        }

        public void LogWarning(string message)
        {
            if (!EventLog.SourceExists("Trizetto .NET Custom Dashboard"))
            {
                EventLog.CreateEventSource("Trizetto .NET Custom Dashboard", "Application");
            }
            EventLog appLog = new System.Diagnostics.EventLog();

            appLog.Log = "Application";
            appLog.Source = "Trizetto .NET Custom Dashboard";

            appLog.WriteEntry(message, EventLogEntryType.Warning, 202);


        }
    }
}