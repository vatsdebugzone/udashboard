﻿//using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CustomDashboardCards.Models;
//using Microsoft.Extensions.Configuration;
//using Microsoft.Extensions.Logging;
using System.Data;
using System.IO;
using System.Web;
using System.Web.Mvc;
using System.Text.Json;


namespace CustomDashboardCards.Controllers
{
    public class HomeController : Controller
    {
        EventLogger _logger = new EventLogger();

        public HomeController()
        {
        }

        public bool RandomizeData
        {
            get { return true; }
        }
        

        public string _basepath
        {
            get { return Directory.GetCurrentDirectory(); }
        }

        /*
        [Route("")]
        [Route("Home")]
        [Route("Home/Index")]
        [HttpGet]
        public ActionResult Index()
        {

            _logger.LogWarning(" Home:IactionResult:Index:Entering");

            TempData["session"] = "|";

            _logger.LogWarning("Home:IactionResult:Index:TempData is set to |");

            return View();
        }
        */

        [Route("Home/LoadCensusData")]
        [HttpPost]
        public string LoadCensusData()
        {
            dal daCustom = new dal();
            string jsonResult = "";
            try
            {
                jsonResult = (string)daCustom.GetCensusData();
            }
            catch (Exception e)
            {
                _logger.WriteMessage($"Error getting census data: {e}", "ERROR");
                throw;
            }
               
            return jsonResult;
        }


        [HttpGet]
        public ActionResult CensusDashboard(string ExternalUserID)
        {
            return View("Dashboards/CensusDashboard");
        }

        /*
        [HttpGet]
        public ActionResult TOCDashboard(string ExternalUserID)
        {
            return View("Dashboards/TOCDashboard");
        }
        */
    }
}

