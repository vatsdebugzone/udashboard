using Microsoft.AspNetCore.Mvc;

namespace UserDashboard.Controllers
{
    public class ProgramDurationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ProgramDuration()
        {
            return View();
        }
    }
}
