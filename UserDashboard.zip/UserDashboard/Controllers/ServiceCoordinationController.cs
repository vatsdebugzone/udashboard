using Microsoft.AspNetCore.Mvc;

namespace UserDashboard.Controllers
{
    public class ServiceCoordinationController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ServiceCoordination()
        {
            return View();
        }
    }
}
