using System.Data;
using Dashboard.Application;
using Dashboard.Domain;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace Dashboard.Infrastructure;

public sealed class AssignmentRepository(IConfiguration configuration) : IAssignmentRepository
{
    public async Task<IReadOnlyList<AssignedCase>> GetAssignedCasesAsync(string userId, CancellationToken cancellationToken)
    {
        _ = ParsedUserId.Parse(userId);
        var connectionString = configuration.GetConnectionString("CcaDb");
        if (string.IsNullOrWhiteSpace(connectionString) || connectionString.Contains("YOUR_SQL_SERVER", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("ConnectionStrings:CcaDb is not configured.");
        }

        var storedProcedure = configuration["Dashboard:AssignmentStoredProcedure"]
            ?? "dbo.chc_GetAssignedCasesMembers";
        if (!IsSafeSqlIdentifier(storedProcedure))
        {
            throw new InvalidOperationException("Dashboard:AssignmentStoredProcedure must be a qualified SQL identifier.");
        }

        await using var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);
        var rows = await connection.QueryAsync<AssignedCase>(new CommandDefinition(
            storedProcedure,
            new { UserId = userId },
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken));
        return rows.AsList();
    }

    private static bool IsSafeSqlIdentifier(string value) =>
        value.Split('.').Length is 1 or 2 &&
        value.Split('.').All(part => part.Length > 0 && part.All(character => char.IsLetterOrDigit(character) || character == '_'));
}