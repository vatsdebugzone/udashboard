using System.Globalization;
using Dashboard.Application;
using Dashboard.Domain;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

namespace Dashboard.Infrastructure;

public sealed class DashboardDataService(
    IDashboardSettingsProvider settingsProvider,
    ICareAdvanceClient careAdvanceClient,
    IAssignmentRepository assignmentRepository,
    IMemoryCache cache,
    ILogger<DashboardDataService> logger) : IDashboardDataService
{
    public async Task<DashboardSummaryResponse> GetSummaryAsync(
        DashboardCard card, string callerUserId, string viewRootId, CancellationToken cancellationToken)
    {
        var correlationId = Guid.NewGuid().ToString("N");
        var config = await settingsProvider.GetAsync(cancellationToken);
        Validate(config);
        var team = await careAdvanceClient.GetTeamTreeAsync(callerUserId, config, cancellationToken);
        var root = FindUser(team, viewRootId) ?? throw new UnauthorizedAccessException();
        var breadcrumb = FindPath(team, viewRootId) ?? throw new UnauthorizedAccessException();
        var users = Flatten(root).ToArray();
        var casesByUser = await GetAssignmentsAsync(users, config, cancellationToken);
        var memberSnapshots = card == DashboardCard.Enrollment
            ? new Dictionary<string, MemberSnapshot>(StringComparer.OrdinalIgnoreCase)
            : await LoadSnapshotsAsync(casesByUser.Values.SelectMany(rows => rows).ToArray(), config, cancellationToken);

        var perUser = users.ToDictionary(
            user => user.Id,
            user => Counts(card, casesByUser[user.Id], memberSnapshots),
            StringComparer.OrdinalIgnoreCase);
        var rows = new List<SummaryRow>
        {
            new(root.Id, root.DisplayName, "Self", perUser[root.Id], null, false)
        };
        foreach (var child in root.Subordinates)
        {
            var group = Flatten(child).ToArray();
            rows.Add(new SummaryRow(
                child.Id,
                child.DisplayName,
                child.Subordinates.Count > 0 ? "Team" : "User",
                Rollup(card, group, casesByUser, memberSnapshots),
                child.Subordinates.Count > 0 ? group.Length : null,
                child.Subordinates.Count > 0));
        }

        var warnings = memberSnapshots.Values.Any(value => value.Unavailable)
            ? new[] { "Some member concept lookups were unavailable; affected values are shown as Unknown." }
            : Array.Empty<string>();
        logger.LogInformation("Dashboard summary loaded. CorrelationId={CorrelationId} Card={Card} CallerUserId={CallerUserId} Outcome=Success", correlationId, card, callerUserId);
        return new DashboardSummaryResponse(
            new SummaryContext(callerUserId, viewRootId, breadcrumb.Select(item => new BreadcrumbItem(item.Id, item.DisplayName)).ToArray()),
            rows,
            Rollup(card, users, casesByUser, memberSnapshots),
            DateTimeOffset.UtcNow,
            warnings.Length > 0,
            warnings);
    }

    public async Task<DashboardDetailResponse> GetDetailAsync(
        DashboardCard card, string callerUserId, string userId, CancellationToken cancellationToken)
    {
        var correlationId = Guid.NewGuid().ToString("N");
        var config = await settingsProvider.GetAsync(cancellationToken);
        Validate(config);
        var team = await careAdvanceClient.GetTeamTreeAsync(callerUserId, config, cancellationToken);
        var user = FindUser(team, userId) ?? throw new UnauthorizedAccessException();
        var cases = await GetAssignmentsAsync([user], config, cancellationToken);
        var assignments = cases[user.Id];
        var snapshots = await LoadSnapshotsAsync(assignments, config, cancellationToken);
        var rows = assignments
            .GroupBy(item => item.CaseId, StringComparer.OrdinalIgnoreCase)
            .Select(group => group.First())
            .Select(item => ToDetailRow(card, item, snapshots.GetValueOrDefault(MemberKey(item))))
            .Where(item => card != DashboardCard.Duration || item.OverduePrograms.Count > 0)
            .OrderBy(item => item.CaseId, StringComparer.OrdinalIgnoreCase)
            .ToArray();
        var partial = rows.Any(row => row.ConceptsUnavailable);
        logger.LogInformation("Dashboard detail loaded. CorrelationId={CorrelationId} Card={Card} CallerUserId={CallerUserId} Outcome=Success", correlationId, card, callerUserId);
        return new DashboardDetailResponse(
            user.Id,
            user.DisplayName,
            rows,
            partial,
            partial ? ["Some member concept lookups were unavailable; affected values are shown as Unknown."] : []);
    }

    private async Task<Dictionary<string, IReadOnlyList<AssignedCase>>> GetAssignmentsAsync(
        IReadOnlyList<TeamUser> users, DashboardConfiguration config, CancellationToken cancellationToken)
    {
        var output = new System.Collections.Concurrent.ConcurrentDictionary<string, IReadOnlyList<AssignedCase>>(StringComparer.OrdinalIgnoreCase);
        using var limit = new SemaphoreSlim(config.MaxParallelSqlCalls);
        await Task.WhenAll(users.Select(async user =>
        {
            var key = $"assignments:{user.Id}";
            if (cache.TryGetValue(key, out IReadOnlyList<AssignedCase>? cached) && cached is not null)
            {
                output[user.Id] = cached;
                return;
            }
            await limit.WaitAsync(cancellationToken);
            try
            {
                var result = await assignmentRepository.GetAssignedCasesAsync(user.Id, cancellationToken);
                cache.Set(key, result, TimeSpan.FromMinutes(config.CacheMinutes));
                output[user.Id] = result;
            }
            finally { limit.Release(); }
        }));
        return new Dictionary<string, IReadOnlyList<AssignedCase>>(output, StringComparer.OrdinalIgnoreCase);
    }

    private async Task<Dictionary<string, MemberSnapshot>> LoadSnapshotsAsync(
        IReadOnlyList<AssignedCase> cases, DashboardConfiguration config, CancellationToken cancellationToken)
    {
        var members = cases.GroupBy(MemberKey, StringComparer.OrdinalIgnoreCase).Select(group => group.First()).ToArray();
        var output = new System.Collections.Concurrent.ConcurrentDictionary<string, MemberSnapshot>(StringComparer.OrdinalIgnoreCase);
        using var limit = new SemaphoreSlim(config.MaxParallelConceptCalls);
        await Task.WhenAll(members.Select(async item =>
        {
            await limit.WaitAsync(cancellationToken);
            try
            {
                var ids = new HashSet<int>(new[] { config.ScLevelConceptId, config.IspStartDateConceptId, config.IspEndDateConceptId, config.AssessmentDateConceptId }
                    .Where(value => value.HasValue).Select(value => value!.Value));
                foreach (var program in config.Programs)
                {
                    ids.Add(program.StatusConceptId);
                    if (program.StartDateConceptId.HasValue) ids.Add(program.StartDateConceptId.Value);
                    if (program.EndDateConceptId.HasValue) ids.Add(program.EndDateConceptId.Value);
                }
                var values = await careAdvanceClient.GetConceptValuesAsync(new MemberKey(item.SystemId, item.MemberId), ids, config, cancellationToken);
                output[MemberKey(item)] = MakeSnapshot(values, config);
            }
            catch (Exception exception) when (exception is HttpRequestException or TaskCanceledException)
            {
                output[MemberKey(item)] = MemberSnapshot.UnavailableSnapshot;
            }
            finally { limit.Release(); }
        }));
        return new Dictionary<string, MemberSnapshot>(output, StringComparer.OrdinalIgnoreCase);
    }

    private static MemberSnapshot MakeSnapshot(IReadOnlyDictionary<int, string?> values, DashboardConfiguration config)
    {
        var timezone = FindBusinessTimeZone();
        var today = DateOnly.FromDateTime(TimeZoneInfo.ConvertTime(DateTimeOffset.UtcNow, timezone).DateTime);
        var activePrograms = new List<ProgramDetail>();
        var overduePrograms = new List<OverdueProgramDetail>();
        foreach (var program in config.Programs)
        {
            values.TryGetValue(program.StatusConceptId, out var status);
            if (!string.Equals(status, config.ActiveProgramValue, StringComparison.OrdinalIgnoreCase)) continue;
            var start = ReadDate(values, program.StartDateConceptId, config.DateFormat);
            var end = ReadDate(values, program.EndDateConceptId, config.DateFormat);
            var assessment = DurationRuleEngine.Classify(program.DurationRule, true, start, end, today, config.Holidays);
            var durationStatus = assessment.Status switch
            {
                DurationStatus.Overdue => "Overdue",
                DurationStatus.NearingDue => "Nearing Due",
                DurationStatus.Compliant => "Compliant",
                DurationStatus.NotApplicable => "Not Applicable",
                _ => "Unknown"
            };
            activePrograms.Add(new ProgramDetail(program.Name, program.Name, status!, start, end, durationStatus));
            if (assessment.Status == DurationStatus.Overdue) overduePrograms.Add(new OverdueProgramDetail(program.Name, end));
        }

        var level = config.ScLevelConceptId.HasValue && values.TryGetValue(config.ScLevelConceptId.Value, out var rawLevel)
            ? NormalizeScLevel(rawLevel)
            : "Unknown";
        var lastAssessment = ReadDate(values, config.AssessmentDateConceptId, config.DateFormat);
        var statusText = AssessmentRuleEngine.Evaluate(level, lastAssessment, today).Status switch
        {
            AssessmentStatus.InCompliance => "In compliant",
            AssessmentStatus.NearDue => "Near due",
            AssessmentStatus.Overdue => "Overdue",
            AssessmentStatus.NoAssessment => "No assessment found",
            _ => "Unknown"
        };
        return new MemberSnapshot(
            activePrograms,
            overduePrograms,
            level,
            lastAssessment,
            ReadDate(values, config.IspStartDateConceptId, config.DateFormat),
            ReadDate(values, config.IspEndDateConceptId, config.DateFormat),
            statusText,
            false);
    }

    private static DashboardDetailRow ToDetailRow(DashboardCard card, AssignedCase item, MemberSnapshot? snapshot)
    {
        snapshot ??= MemberSnapshot.UnavailableSnapshot;
        return new DashboardDetailRow(
            item.CaseId, item.CaseName, item.SystemId, item.MemberId, item.MemberName,
            snapshot.Programs,
            card == DashboardCard.Enrollment ? [] : snapshot.OverduePrograms,
            card == DashboardCard.ScLevel ? snapshot.AssessmentStatus : null,
            card == DashboardCard.ScLevel ? snapshot.LastAssessment : null,
            card == DashboardCard.ScLevel ? snapshot.ScLevel : "Unknown",
            card == DashboardCard.ScLevel ? snapshot.IspStart : null,
            card == DashboardCard.ScLevel ? snapshot.IspEnd : null,
            snapshot.Unavailable);
    }

    private static SummaryCounts Counts(DashboardCard card, IReadOnlyList<AssignedCase> cases, IReadOnlyDictionary<string, MemberSnapshot> snapshots) =>
        card switch
        {
            DashboardCard.Enrollment => new SummaryCounts(Cases: cases.Select(item => item.CaseId).Distinct(StringComparer.OrdinalIgnoreCase).Count()),
            DashboardCard.Duration => ProgramCounts(cases, snapshots),
            DashboardCard.ScLevel => LevelCounts(cases, snapshots),
            _ => new SummaryCounts()
        };

    private static SummaryCounts Rollup(
        DashboardCard card,
        IReadOnlyList<TeamUser> users,
        IReadOnlyDictionary<string, IReadOnlyList<AssignedCase>> casesByUser,
        IReadOnlyDictionary<string, MemberSnapshot> snapshots)
    {
        var allCases = users.SelectMany(user => casesByUser[user.Id]).ToArray();
        if (card == DashboardCard.Enrollment)
            return new SummaryCounts(Cases: allCases.Select(item => item.CaseId).Distinct(StringComparer.OrdinalIgnoreCase).Count());
        return Counts(card, allCases.GroupBy(item => (item.UserId, item.CaseId), new UserCaseComparer())
            .Select(group => group.First()).ToArray(), snapshots);
    }

    private static SummaryCounts ProgramCounts(IEnumerable<AssignedCase> cases, IReadOnlyDictionary<string, MemberSnapshot> snapshots)
    {
        var counts = new SummaryCounts();
        foreach (var member in cases.GroupBy(MemberKey, StringComparer.OrdinalIgnoreCase))
        {
            var snapshot = snapshots.GetValueOrDefault(member.Key);
            if (snapshot is null) continue;
            counts = counts with
            {
                Overdue = counts.Overdue + snapshot.Programs.Count(program => program.DurationStatus == "Overdue"),
                NearingDue = counts.NearingDue + snapshot.Programs.Count(program => program.DurationStatus == "Nearing Due"),
                Compliant = counts.Compliant + snapshot.Programs.Count(program => program.DurationStatus == "Compliant")
            };
        }
        return counts;
    }

    private static SummaryCounts LevelCounts(IEnumerable<AssignedCase> cases, IReadOnlyDictionary<string, MemberSnapshot> snapshots)
    {
        var levels = cases.GroupBy(MemberKey, StringComparer.OrdinalIgnoreCase)
            .Select(member => snapshots.GetValueOrDefault(member.Key)?.ScLevel ?? "Unknown").ToArray();
        return new SummaryCounts(
            Level1: levels.Count(level => level == "1"),
            Level1NF: levels.Count(level => level == "1NF"),
            Level2: levels.Count(level => level == "2"),
            Level3: levels.Count(level => level == "3"),
            Unknown: levels.Count(level => level == "Unknown"));
    }

    private static DateOnly? ReadDate(IReadOnlyDictionary<int, string?> values, int? id, string format)
    {
        if (!id.HasValue || !values.TryGetValue(id.Value, out var raw) || string.IsNullOrWhiteSpace(raw)) return null;
        if (DateOnly.TryParseExact(raw, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out var date)) return date;
        return DateOnly.TryParse(raw, CultureInfo.InvariantCulture, DateTimeStyles.None, out date) ? date : null;
    }

    private static string NormalizeScLevel(string? value)
    {
        if (string.IsNullOrWhiteSpace(value)) return "Unknown";
        var normalized = value.Trim().ToUpperInvariant();
        if (normalized.Contains("1NF", StringComparison.Ordinal)) return "1NF";
        if (normalized.Contains('1')) return "1";
        if (normalized.Contains('2')) return "2";
        if (normalized.Contains('3')) return "3";
        return "Unknown";
    }

    private static TeamUser? FindUser(TeamUser root, string id)
    {
        if (string.Equals(root.Id, id, StringComparison.OrdinalIgnoreCase)) return root;
        foreach (var child in root.Subordinates)
        {
            var found = FindUser(child, id);
            if (found is not null) return found;
        }
        return null;
    }

    private static IReadOnlyList<TeamUser>? FindPath(TeamUser root, string id)
    {
        if (string.Equals(root.Id, id, StringComparison.OrdinalIgnoreCase)) return [root];
        foreach (var child in root.Subordinates)
        {
            var path = FindPath(child, id);
            if (path is not null) return new[] { root }.Concat(path).ToArray();
        }
        return null;
    }

    private static IEnumerable<TeamUser> Flatten(TeamUser user)
    {
        yield return user;
        foreach (var child in user.Subordinates)
            foreach (var descendant in Flatten(child)) yield return descendant;
    }

    private static string MemberKey(AssignedCase item) => $"{item.SystemId}-{item.MemberId}";

    private static TimeZoneInfo FindBusinessTimeZone()
    {
        try { return TimeZoneInfo.FindSystemTimeZoneById("America/Chicago"); }
        catch (TimeZoneNotFoundException) { return TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time"); }
    }

    private static void Validate(DashboardConfiguration config)
    {
        if (string.IsNullOrWhiteSpace(config.CareAdvanceBaseUrl) || string.IsNullOrWhiteSpace(config.UserApiPath) ||
            string.IsNullOrWhiteSpace(config.ConceptApiPath) || string.IsNullOrWhiteSpace(config.Issuer) ||
            string.IsNullOrWhiteSpace(config.Audience) || string.IsNullOrWhiteSpace(config.Subject))
            throw new InvalidOperationException("Dashboard configuration is incomplete. Check active Auth and CareAdvance rows in chct_Dashboard_Config.");
    }

    private sealed record MemberSnapshot(
        IReadOnlyList<ProgramDetail> Programs,
        IReadOnlyList<OverdueProgramDetail> OverduePrograms,
        string ScLevel,
        DateOnly? LastAssessment,
        DateOnly? IspStart,
        DateOnly? IspEnd,
        string AssessmentStatus,
        bool Unavailable)
    {
        public static MemberSnapshot UnavailableSnapshot { get; } = new([], [], "Unknown", null, null, null, "Unknown", true);
    }

    private sealed class UserCaseComparer : IEqualityComparer<(string UserId, string CaseId)>
    {
        public bool Equals((string UserId, string CaseId) x, (string UserId, string CaseId) y) =>
            StringComparer.OrdinalIgnoreCase.Equals(x.UserId, y.UserId) && StringComparer.OrdinalIgnoreCase.Equals(x.CaseId, y.CaseId);
        public int GetHashCode((string UserId, string CaseId) value) =>
            HashCode.Combine(StringComparer.OrdinalIgnoreCase.GetHashCode(value.UserId), StringComparer.OrdinalIgnoreCase.GetHashCode(value.CaseId));
    }
}