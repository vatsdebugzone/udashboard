using System.IdentityModel.Tokens.Jwt;
using System.Text;
using Dashboard.Application;
using Dashboard.Domain;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;

namespace Dashboard.Infrastructure;

public sealed class CareAdvanceTokenService(
    IDashboardConfigurationRepository repository,
    IConfiguration appConfiguration,
    IMemoryCache cache) : ITokenService
{
    private static readonly SemaphoreSlim TokenGate = new(1, 1);
    private const string CacheKey = "careadvance:bearer-token";

    public async Task<string> GetBearerTokenAsync(DashboardConfiguration configuration, CancellationToken cancellationToken)
    {
        if (cache.TryGetValue(CacheKey, out string? cachedToken) && !string.IsNullOrWhiteSpace(cachedToken)) return cachedToken;

        await TokenGate.WaitAsync(cancellationToken);
        try
        {
            if (cache.TryGetValue(CacheKey, out cachedToken) && !string.IsNullOrWhiteSpace(cachedToken)) return cachedToken;
            if (string.IsNullOrWhiteSpace(configuration.Issuer) ||
                string.IsNullOrWhiteSpace(configuration.Audience) ||
                string.IsNullOrWhiteSpace(configuration.Subject))
            {
                throw new InvalidOperationException("Auth issuer, audience, and subject must be configured in chct_Dashboard_Config.");
            }

            var signingKey = await repository.GetJwtSigningKeyAsync(configuration.Issuer, cancellationToken);
            if (string.IsNullOrWhiteSpace(signingKey))
                throw new InvalidOperationException("JWT signing key was not found for the configured issuer.");

            var lifetimeMinutes = Math.Clamp(appConfiguration.GetValue("Auth:TokenLifetimeMinutes", 5), 1, 60);
            var now = DateTime.UtcNow;
            var expires = now.AddMinutes(lifetimeMinutes);
            var credentials = new SigningCredentials(
                new SymmetricSecurityKey(Encoding.UTF8.GetBytes(signingKey)),
                SecurityAlgorithms.HmacSha256);
            var jwt = new JwtSecurityToken(
                issuer: configuration.Issuer,
                audience: configuration.Audience,
                claims: [new System.Security.Claims.Claim(JwtRegisteredClaimNames.Sub, configuration.Subject)],
                notBefore: now.AddSeconds(-5),
                expires: expires,
                signingCredentials: credentials);
            var serialized = new JwtSecurityTokenHandler().WriteToken(jwt);
            cache.Set(CacheKey, serialized, expires.AddSeconds(-45));
            return serialized;
        }
        finally
        {
            TokenGate.Release();
        }
    }
}