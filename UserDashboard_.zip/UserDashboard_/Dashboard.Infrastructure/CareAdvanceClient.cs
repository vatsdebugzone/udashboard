using System.Collections.Concurrent;
using System.Globalization;
using System.Net.Http.Headers;
using System.Text.Json;
using Dashboard.Application;
using Dashboard.Domain;
using Microsoft.Extensions.Caching.Memory;

namespace Dashboard.Infrastructure;

public sealed class CareAdvanceClient(HttpClient httpClient, ITokenService tokenService, IMemoryCache cache) : ICareAdvanceClient
{
    public async Task<TeamUser> GetTeamTreeAsync(
        string rootUserId,
        DashboardConfiguration configuration,
        CancellationToken cancellationToken)
    {
        var root = await cache.GetOrCreateAsync($"team:{rootUserId}", async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(configuration.CacheMinutes);
            return await BuildUserAsync(rootUserId, 0, new HashSet<string>(StringComparer.OrdinalIgnoreCase), configuration, cancellationToken);
        });
        return root ?? throw new HttpRequestException("CareAdvance did not return team information.");
    }

    public async Task<IReadOnlyDictionary<int, string?>> GetConceptValuesAsync(
        MemberKey member,
        IEnumerable<int> conceptIds,
        DashboardConfiguration configuration,
        CancellationToken cancellationToken)
    {
        var ids = conceptIds.Where(id => id > 0).Distinct().Order().ToArray();
        if (ids.Length == 0) return new Dictionary<int, string?>();
        var key = $"concepts:{member.CareAdvanceId}:{string.Join(',', ids)}";
        if (cache.TryGetValue(key, out IReadOnlyDictionary<int, string?>? cached) && cached is not null) return cached;

        var values = new ConcurrentDictionary<int, string?>();
        using var concurrency = new SemaphoreSlim(configuration.MaxParallelConceptCalls);
        var requests = ids.Chunk(10).Select(async batch =>
        {
            await concurrency.WaitAsync(cancellationToken);
            try
            {
                var path = configuration.ConceptApiPath.Replace("{memberId}", Uri.EscapeDataString(member.CareAdvanceId), StringComparison.OrdinalIgnoreCase);
                var uri = BuildUri(configuration.CareAdvanceBaseUrl, path);
                uri += $"{(uri.Contains('?') ? "&" : "?")}ids={Uri.EscapeDataString(string.Join(',', batch))}";
                using var response = await SendAuthorizedAsync(uri, configuration, cancellationToken);
                response.EnsureSuccessStatusCode();
                await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
                using var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
                foreach (var item in ParseConcepts(document.RootElement)) values[item.Key] = item.Value;
            }
            finally
            {
                concurrency.Release();
            }
        });
        await Task.WhenAll(requests);
        IReadOnlyDictionary<int, string?> result = values;
        cache.Set(key, result, TimeSpan.FromMinutes(configuration.CacheMinutes));
        return result;
    }

    private async Task<TeamUser> BuildUserAsync(
        string userId,
        int depth,
        HashSet<string> visited,
        DashboardConfiguration configuration,
        CancellationToken cancellationToken)
    {
        if (depth > configuration.MaxTeamDepth) throw new InvalidOperationException("Team hierarchy exceeded the configured maximum depth.");
        if (!visited.Add(userId)) throw new InvalidOperationException("A cycle was found in the CareAdvance team hierarchy.");
        try
        {
            var data = await LoadTeamPagesAsync(userId, configuration, cancellationToken);
            var children = new List<TeamUser>();
            foreach (var subordinate in data.Subordinates.Where(user => user.Active && !user.OnHold))
            {
                children.Add(subordinate.SubordinateCount > 0
                    ? await BuildUserAsync(subordinate.Id, depth + 1, visited, configuration, cancellationToken)
                    : subordinate);
            }
            return data.User with { Subordinates = children };
        }
        finally
        {
            visited.Remove(userId);
        }
    }

    private async Task<TeamPageData> LoadTeamPagesAsync(
        string userId,
        DashboardConfiguration configuration,
        CancellationToken cancellationToken)
    {
        TeamUser? rootUser = null;
        var subordinates = new Dictionary<string, TeamUser>(StringComparer.OrdinalIgnoreCase);
        var skip = 0;
        var totalCount = int.MaxValue;
        while (skip < totalCount)
        {
            var path = configuration.UserApiPath.Replace("{id}", Uri.EscapeDataString(userId), StringComparison.OrdinalIgnoreCase);
            var uri = BuildUri(configuration.CareAdvanceBaseUrl, path);
            uri += $"{(uri.Contains('?') ? "&" : "?")}limit={configuration.UserPageSize}&skip={skip}";
            using var response = await SendAuthorizedAsync(uri, configuration, cancellationToken);
            response.EnsureSuccessStatusCode();
            await using var stream = await response.Content.ReadAsStreamAsync(cancellationToken);
            using var document = await JsonDocument.ParseAsync(stream, cancellationToken: cancellationToken);
            var (user, pageUsers, pageTotal) = ParseTeamResponse(document.RootElement, userId);
            rootUser ??= user;
            foreach (var subordinate in pageUsers)
            {
                if (!string.IsNullOrWhiteSpace(subordinate.Id) && subordinate.Active && !subordinate.OnHold)
                    subordinates[subordinate.Id] = subordinate;
            }
            totalCount = pageTotal ?? (pageUsers.Count < configuration.UserPageSize
                ? skip + pageUsers.Count
                : skip + configuration.UserPageSize);
            skip += configuration.UserPageSize;
            if (pageUsers.Count == 0) break;
        }
        if (rootUser is null) throw new HttpRequestException("CareAdvance did not return the requested user.");
        return new TeamPageData(rootUser, subordinates.Values.ToArray());
    }

    private static (TeamUser User, IReadOnlyList<TeamUser> Subordinates, int? TotalCount) ParseTeamResponse(JsonElement root, string requestedUserId)
    {
        var data = Property(root, "data") ?? root;
        var user = ParseUser(Property(data, "user") ?? data, requestedUserId);
        var subordinates = Property(data, "subordinates");
        var users = subordinates is { ValueKind: JsonValueKind.Array } array
            ? array.EnumerateArray().Select(value => ParseUser(value, string.Empty)).Where(value => value.Id.Length > 0).ToArray()
            : Array.Empty<TeamUser>();
        var totalValue = Property(data, "totalCount");
        var total = totalValue is { ValueKind: JsonValueKind.Number } number && number.TryGetInt32(out var count) ? count : (int?)null;
        return (user, users, total);
    }

    private static TeamUser ParseUser(JsonElement value, string fallbackId) => new(
        String(value, "id") ?? fallbackId,
        String(value, "displayName") ?? fallbackId,
        Boolean(value, "active", true),
        Boolean(value, "onHold", false),
        Integer(value, "subordinateCount", 0),
        []);

    private async Task<HttpResponseMessage> SendAuthorizedAsync(string uri, DashboardConfiguration configuration, CancellationToken cancellationToken)
    {
        var token = await tokenService.GetBearerTokenAsync(configuration, cancellationToken);
        using var request = new HttpRequestMessage(HttpMethod.Get, uri);
        request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);
        using var timeout = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
        timeout.CancelAfter(TimeSpan.FromSeconds(configuration.TimeoutSeconds));
        return await httpClient.SendAsync(request, HttpCompletionOption.ResponseHeadersRead, timeout.Token);
    }

    private static string BuildUri(string baseUrl, string path)
    {
        if (string.IsNullOrWhiteSpace(baseUrl) || string.IsNullOrWhiteSpace(path))
            throw new InvalidOperationException("CareAdvance BaseUrl and API paths must be configured.");
        return new Uri(new Uri(baseUrl.TrimEnd('/') + "/"), path.TrimStart('/')).ToString();
    }

    private static IReadOnlyDictionary<int, string?> ParseConcepts(JsonElement root)
    {
        var output = new Dictionary<int, string?>();
        Visit(root);
        return output;

        void Visit(JsonElement element)
        {
            if (element.ValueKind == JsonValueKind.Array)
            {
                foreach (var item in element.EnumerateArray()) Visit(item);
                return;
            }
            if (element.ValueKind != JsonValueKind.Object) return;

            var id = Property(element, "id") ?? Property(element, "conceptId");
            if (id is { ValueKind: JsonValueKind.Number } idValue && idValue.TryGetInt32(out var conceptId))
            {
                var latest = Property(element, "latestValue");
                var value = latest is { ValueKind: JsonValueKind.Object }
                    ? Property(latest.Value, "value")
                    : Property(element, "value");
                if (value is not null) output[conceptId] = Scalar(value.Value);
            }
            foreach (var property in element.EnumerateObject()) Visit(property.Value);
        }
    }

    private static JsonElement? Property(JsonElement value, string name)
    {
        if (value.ValueKind != JsonValueKind.Object) return null;
        foreach (var property in value.EnumerateObject())
            if (string.Equals(property.Name, name, StringComparison.OrdinalIgnoreCase)) return property.Value;
        return null;
    }

    private static string? String(JsonElement value, string name)
    {
        var element = Property(value, name);
        return element is null ? null : Scalar(element.Value);
    }

    private static bool Boolean(JsonElement value, string name, bool fallback)
    {
        var element = Property(value, name);
        if (element is null) return fallback;
        if (element.Value.ValueKind is JsonValueKind.True or JsonValueKind.False) return element.Value.GetBoolean();
        return bool.TryParse(Scalar(element.Value), out var result) ? result : fallback;
    }

    private static int Integer(JsonElement value, string name, int fallback)
    {
        var element = Property(value, name);
        return element is { ValueKind: JsonValueKind.Number } number && number.TryGetInt32(out var result)
            ? result
            : int.TryParse(element is null ? null : Scalar(element.Value), NumberStyles.Integer, CultureInfo.InvariantCulture, out result)
                ? result
                : fallback;
    }

    private static string? Scalar(JsonElement value) => value.ValueKind switch
    {
        JsonValueKind.String => value.GetString(),
        JsonValueKind.Number => value.GetRawText(),
        JsonValueKind.True => "true",
        JsonValueKind.False => "false",
        JsonValueKind.Null => null,
        _ => value.GetRawText()
    };

    private sealed record TeamPageData(TeamUser User, IReadOnlyList<TeamUser> Subordinates);
}