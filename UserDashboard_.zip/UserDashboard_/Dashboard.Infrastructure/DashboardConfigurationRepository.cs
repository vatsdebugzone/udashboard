using System.Data;
using Dashboard.Application;
using Dapper;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace Dashboard.Infrastructure;

public sealed class DashboardConfigurationRepository(IConfiguration configuration) : IDashboardConfigurationRepository
{
    private const string ConfigSql = """
        SELECT [filter] AS [Filter], param_name AS [Parameter], param_value AS [Value]
        FROM dbo.chct_Dashboard_Config
        WHERE is_active = 1;
        """;

    private const string DurationSql = """
        SELECT Program, Duration, Basis, Compliant_from AS CompliantFrom,
               Compliant_to AS CompliantTo, NearDue_from AS NearDueFrom,
               NearDue_to AS NearDueTo, Overdue,
               Is_business_date AS IsBusinessDate,
               Status_concept AS StatusConcept,
               Start_date_concept AS StartDateConcept,
               End_date_concept AS EndDateConcept
        FROM dbo.chct_Dashboard_Program_Duration;
        """;

    private const string JwtKeySql = "SELECT [key] FROM OLTP.dbo.JWT_ISSUER WHERE iss = @Issuer;";

    public async Task<IReadOnlyList<ConfigRow>> LoadActiveConfigurationAsync(CancellationToken cancellationToken)
    {
        await using var connection = await OpenConnectionAsync(cancellationToken);
        var rows = await connection.QueryAsync<ConfigRow>(new CommandDefinition(
            ConfigSql,
            commandType: CommandType.Text,
            cancellationToken: cancellationToken));
        return rows.AsList();
    }

    public async Task<IReadOnlyList<ProgramDurationRow>> LoadProgramDurationRulesAsync(CancellationToken cancellationToken)
    {
        await using var connection = await OpenConnectionAsync(cancellationToken);
        var rows = await connection.QueryAsync<ProgramDurationRow>(new CommandDefinition(
            DurationSql,
            commandType: CommandType.Text,
            cancellationToken: cancellationToken));
        return rows.AsList();
    }

    public async Task<string?> GetJwtSigningKeyAsync(string issuer, CancellationToken cancellationToken)
    {
        await using var connection = await OpenConnectionAsync(cancellationToken);
        return await connection.QuerySingleOrDefaultAsync<string>(new CommandDefinition(
            JwtKeySql,
            new { Issuer = issuer },
            commandType: CommandType.Text,
            cancellationToken: cancellationToken));
    }

    private async Task<SqlConnection> OpenConnectionAsync(CancellationToken cancellationToken)
    {
        var connectionString = configuration.GetConnectionString("CcaDb");
        if (string.IsNullOrWhiteSpace(connectionString) || connectionString.Contains("YOUR_SQL_SERVER", StringComparison.OrdinalIgnoreCase))
        {
            throw new InvalidOperationException("ConnectionStrings:CcaDb must be set to the customdb SQL Server connection string.");
        }

        var connection = new SqlConnection(connectionString);
        await connection.OpenAsync(cancellationToken);
        return connection;
    }
}