using System.Globalization;
using Dashboard.Application;
using Dashboard.Domain;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;

namespace Dashboard.Infrastructure;

public sealed class DashboardSettingsProvider(
    IConfiguration configuration,
    IDashboardConfigurationRepository repository,
    IMemoryCache cache) : IDashboardSettingsProvider
{
    private const string CacheKey = "dashboard:runtime-settings";

    public async Task<DashboardConfiguration> GetAsync(CancellationToken cancellationToken)
    {
        var result = await cache.GetOrCreateAsync(CacheKey, async entry =>
        {
            var cacheMinutes = configuration.GetValue("Dashboard:CacheMinutes", 10);
            entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(Math.Max(1, cacheMinutes));
            var rows = await repository.LoadActiveConfigurationAsync(cancellationToken);
            var values = rows.ToDictionary(
                row => $"{row.Filter}:{row.Parameter}",
                row => row.Value,
                StringComparer.OrdinalIgnoreCase);
            var durationRows = await repository.LoadProgramDurationRulesAsync(cancellationToken);
            var programs = durationRows.Select(ToProgramDefinition).ToArray();
            var holidays = configuration.GetSection("Holidays").Get<DateOnly[]>() ?? [];

            return new DashboardConfiguration(
                Get("Auth:issuer", "Auth:Issuer"),
                Get("Auth:audience", "Auth:Audience"),
                Get("Auth:subject", "Auth:Subject"),
                Get("CareAdvance:BaseUrl", "CareAdvance:BaseUrl"),
                Get("CareAdvance:UserApiPath", "CareAdvance:UserApiPath"),
                Get("CareAdvance:ConceptApiPath", "CareAdvance:ConceptApiPath"),
                GetInt("CareAdvance:TimeoutSeconds", "CareAdvance:TimeoutSeconds", 30),
                GetInt("Dashboard:UserPageSize", "CareAdvance:UserPageSize", 100),
                GetInt("Dashboard:CacheMinutes", "Dashboard:CacheMinutes", 10),
                GetInt("Dashboard:MaxParallelSqlCalls", "Dashboard:MaxParallelSqlCalls", 5),
                GetInt("Dashboard:MaxParallelConceptCalls", "Dashboard:MaxParallelConceptCalls", 10),
                GetInt("Dashboard:MaxTeamDepth", "Dashboard:MaxTeamDepth", 10),
                GetNullableInt("Dashboard:ScLevelConceptId", "Dashboard:ScLevelConceptId"),
                GetNullableInt("Dashboard:IspStartDateConceptId", "Dashboard:IspStartDateConceptId"),
                GetNullableInt("Dashboard:IspEndDateConceptId", "Dashboard:IspEndDateConceptId"),
                GetNullableInt("Dashboard:AssessmentDateConceptId", "Dashboard:AssessmentDateConceptId"),
                Get("Dashboard:ActiveProgramValue", "Dashboard:ActiveProgramValue", "Active"),
                Get("Dashboard:DateFormat", "Dashboard:DateFormat", "M/d/yyyy"),
                holidays.ToHashSet(),
                programs);

            string Get(string dbKey, string appKey, string? fallback = null)
            {
                if (values.TryGetValue(dbKey, out var value) && !string.IsNullOrWhiteSpace(value)) return value;
                return configuration[appKey] ?? fallback ?? string.Empty;
            }

            int GetInt(string dbKey, string appKey, int fallback) =>
                int.TryParse(Get(dbKey, appKey), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value)
                    ? Math.Max(1, value)
                    : fallback;

            int? GetNullableInt(string dbKey, string appKey) =>
                int.TryParse(Get(dbKey, appKey), NumberStyles.Integer, CultureInfo.InvariantCulture, out var value) && value > 0
                    ? value
                    : null;
        });

        return result ?? throw new InvalidOperationException("Dashboard configuration is unavailable.");
    }

    private static ProgramDefinition ToProgramDefinition(ProgramDurationRow row)
    {
        var basis = row.Basis?.Trim().ToUpperInvariant() switch
        {
            "START" => DurationBasis.StartDate,
            "END" => DurationBasis.EndDate,
            "ELIGIBILITY" => DurationBasis.EligibilityOnly,
            _ => DurationBasis.None
        };
        int? overdueAfter = null;
        if (row.Overdue?.Trim() is { } overdue && overdue.StartsWith('>') &&
            int.TryParse(overdue.AsSpan(1), NumberStyles.Integer, CultureInfo.InvariantCulture, out var parsed))
        {
            overdueAfter = parsed;
        }

        return new ProgramDefinition(
            row.Program,
            row.StatusConcept,
            row.StartDateConcept,
            row.EndDateConcept,
            new ProgramDurationRule(
                row.Program,
                basis,
                row.CompliantFrom,
                row.CompliantTo,
                row.NearDueFrom,
                row.NearDueTo,
                overdueAfter,
                row.IsBusinessDate));
    }
}