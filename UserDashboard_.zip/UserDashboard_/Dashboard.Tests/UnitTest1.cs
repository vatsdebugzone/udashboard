using Dashboard.Domain;

namespace Dashboard.Tests;

public class DurationRuleEngineTests
{
    private static readonly DateOnly Today = new(2026, 11, 16);

    [Theory]
    [InlineData(75, DurationStatus.Compliant)]
    [InlineData(76, DurationStatus.NearingDue)]
    [InlineData(90, DurationStatus.NearingDue)]
    [InlineData(91, DurationStatus.Overdue)]
    public void StartDateRulesClassifyInclusiveBoundaries(int elapsedDays, DurationStatus expected)
    {
        var rule = new ProgramDurationRule("Test", DurationBasis.StartDate, 0, 75, 76, 90, 90);

        var result = DurationRuleEngine.Classify(
            rule,
            true,
            Today.AddDays(-elapsedDays),
            null,
            Today);

        Assert.Equal(expected, result.Status);
        Assert.Equal(elapsedDays, result.Days);
    }

    [Theory]
    [InlineData(165, AssessmentStatus.InCompliance)]
    [InlineData(166, AssessmentStatus.NearDue)]
    [InlineData(180, AssessmentStatus.NearDue)]
    [InlineData(181, AssessmentStatus.Overdue)]
    public void LevelTwoAssessmentUses180DayFrequency(int days, AssessmentStatus expected)
    {
        var result = AssessmentRuleEngine.Evaluate("2", Today.AddDays(-days), Today);

        Assert.Equal(expected, result.Status);
        Assert.Equal(days, result.DaysSinceLastAssessment);
    }

    [Theory]
    [InlineData(75, AssessmentStatus.InCompliance)]
    [InlineData(76, AssessmentStatus.NearDue)]
    [InlineData(90, AssessmentStatus.NearDue)]
    [InlineData(91, AssessmentStatus.Overdue)]
    public void LevelOneAssessmentUses90DayFrequency(int days, AssessmentStatus expected)
    {
        var result = AssessmentRuleEngine.Evaluate("1NF", Today.AddDays(-days), Today);

        Assert.Equal(expected, result.Status);
    }

    [Fact]
    public void ExpiredEndDateIsOverdue()
    {
        var rule = new ProgramDurationRule("End based", DurationBasis.EndDate, 91, null, 0, 90);

        var result = DurationRuleEngine.Classify(rule, true, null, Today.AddDays(-1), Today);

        Assert.Equal(DurationStatus.Overdue, result.Status);
        Assert.Equal(-1, result.Days);

    }
}