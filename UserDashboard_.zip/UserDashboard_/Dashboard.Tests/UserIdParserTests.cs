using Dashboard.Domain;

namespace Dashboard.Tests;

public class UserIdParserTests
{
    [Theory]
    [InlineData("0-testUser1", 0, "testUser1")]
    [InlineData("12-external-id-with-hyphens", 12, "external-id-with-hyphens")]
    public void ParseAcceptsSystemAndExternalId(string value, int expectedSystemId, string expectedExternalId)
    {
        var parsed = ParsedUserId.Parse(value);

        Assert.Equal(expectedSystemId, parsed.SystemId);
        Assert.Equal(expectedExternalId, parsed.ExternalId);
    }

    [Theory]
    [InlineData(null)]
    [InlineData("")]
    [InlineData("user")]
    [InlineData("x-user")]
    [InlineData("1-")]
    public void ParseRejectsInvalidUserIds(string? value)
    {
        Assert.Throws<FormatException>(() => ParsedUserId.Parse(value));
    }
}