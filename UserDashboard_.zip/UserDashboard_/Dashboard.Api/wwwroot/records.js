const cards = {
  enrollment: { label: "Program Enrollment", slug: "enrollment" },
  duration: { label: "Program Duration", slug: "duration" },
  "sc-level": { label: "Service Coordination Level", slug: "sc-level" }
};

const query = new URLSearchParams(window.location.search);
const cardKey = query.get("card");
const card = cards[cardKey] ? cards[cardKey] : cards.enrollment;
const userId = query.get("userId") || "";
const callerUserId = query.get("callerUserId") || "";
const displayName = query.get("displayName") || userId || "Assigned cases";
const isDemo = query.get("demo") === "1";
const tableHead = document.querySelector("#records-head");
const tableBody = document.querySelector("#records-body");
const notice = document.querySelector("#records-notice");

document.querySelector("#records-person").textContent = displayName;
document.querySelector("#records-copy").textContent = `${card.label} records assigned to ${displayName}.`;
document.querySelector("#records-card-label").textContent = card.label.toUpperCase();
document.querySelector("#signed-in-user").textContent = callerUserId || "Sample preview";
document.querySelector("#records-footer").textContent = isDemo ? "Fictional sample data" : "Secure connection";

const backUrl = new URL("/", window.location.origin);
if (!isDemo && callerUserId) backUrl.searchParams.set("userId", callerUserId);
if (cardKey && cards[cardKey]) backUrl.searchParams.set("card", cardKey);
document.querySelector("#back-to-dashboard").href = backUrl;

const columns = cardKey === "sc-level"
  ? [
      ["caseId", "Case ID"], ["caseName", "Case name"], ["memberName", "Member"],
      ["assessment", "Assessment status"], ["scLevel", "SC level"],
      ["ispStartDate", "ISP start"], ["ispEndDate", "ISP end"], ["programs", "Programs assigned"]
    ]
  : [["caseId", "Case ID"], ["caseName", "Case name"], ["memberName", "Member"], ["programs", "Programs assigned"]];

tableHead.append(makeRow(columns.map(([, label]) => {
  const cell = document.createElement("th");
  cell.scope = "col";
  cell.textContent = label;
  return cell;
})));

async function loadRecords() {
  try {
    let rows;
    if (isDemo) {
      rows = demoRows[userId] || [];
    } else {
      if (!userId || !callerUserId) throw new Error("Missing user context");
      const url = new URL(`/api/dashboard/${card.slug}/users/${encodeURIComponent(userId)}/detail`, window.location.origin);
      url.searchParams.set("callerUserId", callerUserId);
      const response = await fetch(url, { headers: { Accept: "application/json" }, cache: "no-store" });
      if (!response.ok) throw new Error(`Detail request failed: ${response.status}`);
      const payload = await response.json();
      rows = payload.rows || [];
    }

    tableBody.replaceChildren();
    if (!rows.length) {
      const emptyRow = document.createElement("tr");
      const emptyCell = document.createElement("td");
      emptyCell.className = "empty-row";
      emptyCell.colSpan = columns.length;
      emptyCell.textContent = "No data available in table";
      emptyRow.append(emptyCell);
      tableBody.append(emptyRow);
      return;
    }

    rows.forEach((row) => {
      tableBody.append(renderRecord(row));
      if (cardKey !== "enrollment") {
        (row.overduePrograms || []).forEach((program) => tableBody.append(renderOverdue(program)));
      }
    });
  } catch {
    notice.hidden = false;
    notice.dataset.level = "error";
    notice.textContent = "Case details could not be loaded. Check the dashboard connection and try again.";
    document.querySelector("#records-footer").textContent = "Data unavailable";
  }
}

function renderRecord(row) {
  const tr = document.createElement("tr");
  const status = String(row.assessmentStatus || row.submissionStatus || row.status || "").toLowerCase();
  if (status.includes("rejected") || status.includes("overdue") || row.overduePrograms?.length) tr.classList.add("detail-status-rejected");
  else if (status.includes("accepted") || status.includes("compliant")) tr.classList.add("detail-status-accepted");
  else if (status.includes("near") || status.includes("pending") || status.includes("unknown")) tr.classList.add("detail-status-other");

  columns.forEach(([key]) => {
    const cell = document.createElement("td");
    if (key === "caseId") {
      const link = document.createElement("button");
      link.className = "case-link";
      link.type = "button";
      link.textContent = row.caseId || "";
      link.addEventListener("click", () => openCase(row));
      cell.append(link);
    } else if (key === "programs") {
      cell.append(renderPrograms(row.programsAssigned));
    } else if (key === "assessment") {
      cell.append(renderStatus(row.assessmentStatus));
    } else if (key === "ispStartDate" || key === "ispEndDate") {
      cell.textContent = formatDate(row[key]);
    } else if (key === "scLevel") {
      cell.textContent = row.scLevel || "Unknown";
    } else {
      cell.textContent = row[key] || "";
    }
    tr.append(cell);
  });
  return tr;
}

function renderPrograms(programs) {
  const list = document.createElement("div");
  list.className = "program-list";
  (programs || []).forEach((program) => {
    const item = document.createElement("div");
    const name = document.createElement("span");
    name.className = "program-name";
    name.textContent = program.name || program.code || "Program";
    const meta = document.createElement("span");
    meta.className = "program-meta";
    meta.textContent = [program.status, formatDate(program.startDate), formatDate(program.endDate)].filter(Boolean).join(" / ");
    item.append(name, meta);
    list.append(item);
  });
  if (!programs?.length) list.textContent = "None recorded";
  return list;
}

function renderStatus(value) {
  const normalized = String(value || "").toLowerCase();
  const pill = document.createElement("span");
  pill.className = "status-pill " + (normalized.includes("rejected") || normalized.includes("overdue")
    ? "pill-overdue"
    : normalized.includes("accepted") || normalized.includes("compliant")
      ? "pill-compliant"
      : normalized.includes("near") ? "pill-near" : "pill-neutral");
  pill.textContent = value || "Unknown";
  return pill;
}

function renderOverdue(program) {
  const row = document.createElement("tr");
  row.className = "subrow";
  const cell = document.createElement("td");
  cell.colSpan = columns.length;
  cell.textContent = `Overdue program: ${program.program || program.name || "Program"} / Due ${formatDate(program.dueDate || program.endDate)}`;
  row.append(cell);
  return row;
}

function openCase(row) {
  const payload = {
    page: "CmCase",
    options: {
      externalMember: { memberId: row.memberId, systemId: String(row.systemId) },
      caseId: row.caseId,
      tab: "careplan"
    }
  };
  if (window.dashboard?.publish) window.dashboard.publish("cca.navigate", payload);
  else showNotice(`Case ${row.caseId} is ready to open in CCA when this page is hosted by the CCA shell.`);
}

function showNotice(message) {
  notice.hidden = false;
  notice.dataset.level = "info";
  notice.textContent = message;
}

function makeRow(cells) {
  const row = document.createElement("tr");
  cells.forEach((cell) => row.append(cell));
  return row;
}

function formatDate(value) {
  if (!value) return "";
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? String(value) : new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(date);
}

const demoRows = {
  "0-demo": [
    { caseId: "CM-DEMO-1042", caseName: "Care coordination follow-up", memberId: "DEMO-8001", systemId: 2, memberName: "Sample Member A", programsAssigned: [{ name: "Community Support", status: "Active", startDate: "2026-03-05", endDate: "2026-12-10" }], assessmentStatus: "In compliant", scLevel: "1NF", ispStartDate: "2026-05-01", ispEndDate: "2027-05-01" },
    { caseId: "CM-DEMO-1088", caseName: "Annual service review", memberId: "DEMO-8002", systemId: 2, memberName: "Sample Member B", programsAssigned: [{ name: "Health Coaching", status: "Active", startDate: "2026-02-01", endDate: "2026-10-30" }], overduePrograms: [{ program: "Health Coaching", dueDate: "2026-10-30" }], assessmentStatus: "Near due", scLevel: "2", ispStartDate: "2026-04-15", ispEndDate: "2027-04-15" }
  ],
  "0-avery": [
    { caseId: "CM-DEMO-1120", caseName: "Member needs assessment", memberId: "DEMO-8003", systemId: 2, memberName: "Sample Member C", programsAssigned: [{ name: "Family Wellness", status: "Active", startDate: "2026-04-20", endDate: "2026-12-01" }], overduePrograms: [], assessmentStatus: "Overdue", scLevel: "1", ispStartDate: "2026-01-10", ispEndDate: "2027-01-10" }
  ],
  "0-sam": [
    { caseId: "CM-DEMO-1144", caseName: "Care plan check-in", memberId: "DEMO-8004", systemId: 2, memberName: "Sample Member D", programsAssigned: [{ name: "Community Support", status: "Active", startDate: "2026-06-12", endDate: "2027-06-12" }], overduePrograms: [], assessmentStatus: "In compliant", scLevel: "1", ispStartDate: "2026-06-12", ispEndDate: "2027-06-12" }
  ]
};

loadRecords();