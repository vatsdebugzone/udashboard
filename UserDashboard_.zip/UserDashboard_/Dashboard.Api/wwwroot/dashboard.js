const cards = {
  enrollment: { label: "Program Enrollment", slug: "enrollment" },
  duration: { label: "Program Duration", slug: "duration" },
  "sc-level": { label: "Service Coordination Level", slug: "sc-level" }
};

const state = {
  card: "enrollment",
  callerUserId: "",
  viewRootId: "",
  breadcrumb: [],
  summaries: {},
  detail: null,
  selectedUser: null,
  teamChart: null,
  demo: false
};

const demoData = createDemoData();
const elements = {
  asOf: document.querySelector("#as-of"),
  breadcrumbs: document.querySelector("#breadcrumbs"),
  detailBody: document.querySelector("#detail-body"),
  detailHead: document.querySelector("#detail-head"),
  detailTitle: document.querySelector("#detail-title"),
  detailView: document.querySelector("#detail-view"),
  environment: document.querySelector("#environment-label"),
  footerState: document.querySelector("#footer-state"),
  headingCopy: document.querySelector("#heading-copy"),
  notice: document.querySelector("#notice"),
  sectionEyebrow: document.querySelector("#section-eyebrow"),
  sectionHint: document.querySelector("#section-hint"),
  sectionTitle: document.querySelector("#section-title"),
  signedInUser: document.querySelector("#signed-in-user"),
  chart: document.querySelector("#team-chart"),
  chartContainer: document.querySelector("#team-chart-container"),
  chartEmpty: document.querySelector("#chart-empty"),
  teamView: document.querySelector("#team-view")
};

document.querySelectorAll(".summary-card").forEach((button) => {
  button.addEventListener("click", () => {
    state.card = button.dataset.card;
    state.detail = null;
    state.selectedUser = null;
    render();
  });
});

document.querySelector("#back-to-team").addEventListener("click", () => {
  state.detail = null;
  state.selectedUser = null;
  render();
});

initialize();

async function initialize() {
  const query = new URLSearchParams(window.location.search);
  const requestedCard = query.get("card");
  if (Object.hasOwn(cards, requestedCard)) state.card = requestedCard;
  state.callerUserId = query.get("userId") || query.get("externalUserId") || document.querySelector('meta[name="dashboard-user-id"]')?.content || "";
  state.viewRootId = state.callerUserId;
  state.demo = !state.callerUserId;

  if (state.demo) {
    state.callerUserId = demoData.rootId;
    state.viewRootId = demoData.rootId;
    state.demo = false;
    state.breadcrumb = [{ userId: demoData.rootId, displayName: "Jordan Lee" }];
    elements.signedInUser.textContent = demoData.rootId;
    elements.environment.textContent = "Sample preview";
    elements.footerState.textContent = "Fictional sample data from API";
    showNotice("Sample preview. Add ?userId={UserId} to load the signed-in user's dashboard.", "info");
    try {
      await loadSummaries();
      render();
    } catch (error) {
      showNotice("The API preview could not be loaded. Check the dashboard connection and refresh.", "error");
      render();
    }
    return;
  }

  state.breadcrumb = [{ userId: state.callerUserId, displayName: "My team" }];
  elements.signedInUser.textContent = state.callerUserId;
  elements.environment.textContent = "Connected dashboard";
  try {
    await loadSummaries();
    render();
  } catch (error) {
    showNotice("Dashboard data could not be loaded. Check the API connection and configuration, then refresh.", "error");
    elements.footerState.textContent = "Data unavailable";
    render();
  }
}

async function loadSummaries() {
  const entries = await Promise.all(Object.entries(cards).map(async ([key, card]) => {
    const url = new URL(`/api/dashboard/${card.slug}/summary`, window.location.origin);
    url.searchParams.set("callerUserId", state.callerUserId);
    url.searchParams.set("viewRootId", state.viewRootId);
    const response = await fetch(url, { headers: { Accept: "application/json" }, cache: "no-store" });
    if (!response.ok) throw new Error(`Summary request failed: ${response.status}`);
    return [key, await response.json()];
  }));
  state.summaries = Object.fromEntries(entries);
  const rootName = state.summaries.enrollment?.context?.breadcrumb?.[0]?.displayName;
  if (rootName) state.breadcrumb[0].displayName = rootName;
}

async function openTeam(userId, displayName) {
  if (state.demo) {
    state.viewRootId = userId;
    state.breadcrumb.push({ userId, displayName });
    state.summaries = demoData.teamSummaries[userId];
    state.detail = null;
    state.selectedUser = null;
    render();
    return;
  }

  state.viewRootId = userId;
  state.breadcrumb.push({ userId, displayName });
  state.summaries = {};
  state.detail = null;
  state.selectedUser = null;
  render();
  try {
    await loadSummaries();
    render();
  } catch {
    showNotice("This team's summary could not be loaded.", "error");
  }
}

async function openDetail(userId, displayName) {
  const url = new URL("/records.html", window.location.origin);
  url.searchParams.set("userId", userId);
  url.searchParams.set("displayName", displayName || userId);
  url.searchParams.set("callerUserId", state.callerUserId);
  url.searchParams.set("card", state.card);
  if (state.demo) url.searchParams.set("demo", "1");
  window.location.assign(url);
}

function render() {
  document.querySelectorAll(".summary-card").forEach((button) => {
    button.setAttribute("aria-pressed", String(button.dataset.card === state.card));
  });
  updateCardTotals();
  renderBreadcrumbs();
  renderTeam();
  renderDetail();

  const summary = state.summaries[state.card];
  const card = cards[state.card];
  elements.sectionEyebrow.textContent = card.label.toUpperCase();
  elements.sectionTitle.textContent = state.detail ? "Assigned cases" : `${card.label} by team member`;
  elements.sectionHint.textContent = state.detail
    ? `Cases assigned to ${state.selectedUser?.displayName || "the selected user"}.`
    : "Select a team bar to drill in, or a member bar to open records.";
  elements.asOf.textContent = formatDateTime(summary?.asOf);
  elements.teamView.hidden = Boolean(state.detail);
  elements.detailView.hidden = !state.detail;
  elements.headingCopy.textContent = state.detail
    ? `${card.label} details for ${state.selectedUser?.displayName || "the selected user"}.`
    : "Assigned cases and member program status across your team.";

  if (summary?.isPartial) {
    showNotice((summary.warnings || []).join(" ") || "Some member concept values are unavailable.", "warning");
  }
}

function updateCardTotals() {
  Object.keys(cards).forEach((key) => {
    const summary = state.summaries[key];
    const totals = summary?.totals || {};
    const total = key === "enrollment"
      ? number(totals.cases)
      : key === "duration"
        ? number(totals.overdue) + number(totals.nearingDue) + number(totals.compliant)
        : ["level1", "level1NF", "level2", "level3"].reduce((sum, item) => sum + number(totals[item]), 0);
    const value = document.querySelector(`[data-total="${key}"]`);
    if (value) value.textContent = formatNumber(total);
  });

  const durationStrip = document.querySelector('[data-status-strip="duration"]');
  const duration = state.summaries.duration?.totals || {};
  if (durationStrip) durationStrip.replaceChildren(
    statusCount("Overdue", duration.overdue, "status-overdue"),
    statusCount("Nearing", duration.nearingDue, "status-nearing"),
    statusCount("Compliant", duration.compliant, "status-compliant")
  );

  const levels = state.summaries["sc-level"]?.totals || {};
  const levelStrip = document.querySelector("[data-level-strip]");
  if (levelStrip) levelStrip.replaceChildren(...[
    ["1", levels.level1], ["1NF", levels.level1NF], ["2", levels.level2], ["3", levels.level3]
  ].map(([label, count]) => {
    const item = document.createElement("span");
    item.className = "level-item";
    item.textContent = `${label} ${formatNumber(count)}`;
    return item;
  }));
}

function renderBreadcrumbs() {
  elements.breadcrumbs.replaceChildren();
  state.breadcrumb.forEach((item, index) => {
    const wrapper = document.createElement("span");
    wrapper.className = "breadcrumb-item";
    if (index > 0) {
      const divider = document.createElement("span");
      divider.className = "crumb-divider";
      divider.setAttribute("aria-hidden", "true");
      divider.textContent = "/";
      wrapper.append(divider);
    }
    if (index === state.breadcrumb.length - 1) {
      const current = document.createElement("span");
      current.className = "breadcrumb-current";
      current.textContent = item.displayName;
      wrapper.append(current);
    } else {
      const button = document.createElement("button");
      button.className = "breadcrumb-button";
      button.type = "button";
      button.textContent = item.displayName;
      button.addEventListener("click", () => returnToBreadcrumb(index));
      wrapper.append(button);
    }
    elements.breadcrumbs.append(wrapper);
  });
}

async function returnToBreadcrumb(index) {
  state.breadcrumb = state.breadcrumb.slice(0, index + 1);
  state.viewRootId = state.breadcrumb[index].userId;
  state.detail = null;
  state.selectedUser = null;
  if (state.demo) {
    state.summaries = state.viewRootId === demoData.rootId ? demoData.summaries : demoData.teamSummaries[state.viewRootId];
    render();
    return;
  }
  state.summaries = {};
  render();
  try {
    await loadSummaries();
    render();
  } catch {
    showNotice("The selected team could not be loaded.", "error");
  }
}

function renderTeam() {
  state.teamChart?.destroy();
  state.teamChart = null;
  const rows = state.summaries[state.card]?.rows || [];
  if (!rows.length) {
    elements.chart.hidden = true;
    elements.chartEmpty.hidden = false;
    return;
  }
  elements.chart.hidden = false;
  elements.chartEmpty.hidden = true;
  if (typeof Chart === "undefined") {
    elements.chart.hidden = true;
    elements.chartEmpty.hidden = false;
    elements.chartEmpty.textContent = "The chart could not be loaded. Refresh the page to try again.";
    return;
  }

  const metricLabel = state.card === "enrollment"
    ? "Assigned cases"
    : state.card === "duration" ? "Member programs" : "Assigned members";
  const series = chartSeries(rows, state.card);
  elements.chartContainer.style.height = `${Math.max(260, rows.length * 52 + 72)}px`;
  elements.chart.setAttribute("aria-label", `${metricLabel} by team member. Select a team bar to drill in or a member bar to open records.`);
  state.teamChart = new Chart(elements.chart, {
    type: "bar",
    data: {
      labels: rows.map((row) => row.displayName || row.id),
      datasets: series.map((item) => ({
        label: item.label,
        data: rows.map((row) => number(row.counts?.[item.key])),
        backgroundColor: item.color,
        borderColor: item.border,
        borderWidth: 1,
        borderRadius: 2,
        barThickness: 24,
        hoverBackgroundColor: item.hover
      }))
    },
    plugins: [{
      id: "bar-value-labels",
      afterDatasetsDraw(chart) {
        const context = chart.ctx;
        context.save();
        context.font = "600 12px Segoe UI, Aptos, sans-serif";
        context.textAlign = "center";
        context.textBaseline = "middle";
        chart.data.datasets.forEach((dataset, datasetIndex) => {
          const meta = chart.getDatasetMeta(datasetIndex);
          if (meta.hidden) return;
          meta.data.forEach((bar, rowIndex) => {
            const value = Number(dataset.data[rowIndex]) || 0;
            if (value === 0 || Math.abs(bar.x - bar.base) < 24) return;
            context.fillStyle = "#fff";
            context.fillText(formatNumber(value), (bar.x + bar.base) / 2, bar.y);
          });
        });
        context.restore();
      }
    }],
    options: {
      indexAxis: "y",
      responsive: true,
      maintainAspectRatio: false,
      interaction: { mode: "nearest", intersect: true },
      onClick: (event, activeElements) => {
        if (activeElements.length) {
          const row = rows[activeElements[0].index];
          window.setTimeout(() => {
            if (row.canDrill) openTeam(row.id, row.displayName || row.id);
            else openDetail(row.id, row.displayName || row.id);
          }, 0);
        }
      },
      onHover: (event, activeElements) => {
        event.native.target.style.cursor = activeElements.length ? "pointer" : "default";
      },
      plugins: {
        legend: {
          display: series.length > 1,
          position: "bottom",
          align: "center",
          labels: { usePointStyle: true, boxWidth: 8, boxHeight: 8, padding: 16, color: "#52615d", font: { family: "Segoe UI, Aptos, sans-serif", size: 12, weight: 600 } }
        },
        tooltip: {
          titleFont: { family: "Segoe UI, Aptos, sans-serif", size: 12 },
          bodyFont: { family: "Segoe UI, Aptos, sans-serif", size: 12 },
          callbacks: { label: (context) => `${context.dataset.label}: ${formatNumber(context.raw)}` }
        }
      },
      scales: {
        x: {
          beginAtZero: true,
          stacked: series.length > 1,
          ticks: { precision: 0, color: "#647574", font: { family: "Segoe UI, Aptos, sans-serif", size: 12 } },
          grid: { color: "#e5e9e6" },
          border: { display: false }
        },
        y: {
          stacked: series.length > 1,
          ticks: { color: "#172a2a", padding: 10, font: { family: "Segoe UI, Aptos, sans-serif", size: 13, weight: 700 } },
          grid: { display: false },
          border: { display: false }
        }
      }
    }
  });
}

function chartSeries(rows, card) {
  if (card === "enrollment") {
    return [{ key: "cases", label: "Assigned cases", color: "#a9cde8", border: "#496c83", hover: "#83b4dc" }];
  }
  if (card === "duration") {
    return [
      { key: "overdue", label: "Overdue", color: "#dc8b80", border: "#a84137", hover: "#ca6e62" },
      { key: "nearingDue", label: "Nearing due", color: "#f1ce7b", border: "#a76d18", hover: "#e5b952" },
      { key: "compliant", label: "Compliant", color: "#91c3a5", border: "#3e7959", hover: "#70aa88" }
    ];
  }
  const levels = [
    { key: "level1", label: "Level 1", color: "#91c3a5", border: "#3e7959", hover: "#70aa88" },
    { key: "level1NF", label: "1NF", color: "#a8cbd1", border: "#466c7a", hover: "#83b5be" },
    { key: "level2", label: "Level 2", color: "#f1ce7b", border: "#a76d18", hover: "#e5b952" },
    { key: "level3", label: "Level 3", color: "#d8c6b3", border: "#80654d", hover: "#c5ad94" }
  ];
  const hasUnknown = rows.some((row) => number(row.counts?.unknown) > 0);
  if (hasUnknown) levels.push({ key: "unknown", label: "Unknown", color: "#c5ceca", border: "#77837e", hover: "#aebbb5" });
  return levels;
}

function renderTotalsRow(totals, columns) {
  const tr = document.createElement("tr");
  tr.className = "total-row";
  const label = document.createElement("th");
  label.scope = "row";
  label.textContent = "View total";
  const caption = document.createElement("span");
  caption.className = "total-caption";
  caption.textContent = "Distinct roll-up";
  label.append(caption);
  tr.append(label);

  columns.slice(1).forEach((column) => {
    const cell = document.createElement("td");
    if (column.key === "counts") cell.append(renderBreakdown(totals, state.card));
    else cell.textContent = "";
    tr.append(cell);
  });
  return tr;
}

function renderTeamRow(row, columns) {
  const tr = document.createElement("tr");
  const person = document.createElement("td");
  person.className = "person-cell";
  const name = document.createElement("span");
  name.className = "person-name";
  name.textContent = row.displayName || row.id;
  if (row.rowType === "Team") {
    const tag = document.createElement("span");
    tag.className = "team-tag";
    tag.textContent = "TEAM";
    name.append(tag);
  }
  const caption = document.createElement("span");
  caption.className = "person-caption";
  caption.textContent = row.rowType === "Self" ? "Viewed user" : row.rowType === "Team" ? `${number(row.memberCount)} people in team` : "Direct report";
  person.append(name, caption);
  tr.append(person);

  columns.slice(1).forEach((column) => {
    const cell = document.createElement("td");
    if (column.key === "action") {
      const button = document.createElement("button");
      button.className = "row-action";
      button.type = "button";
      button.textContent = row.canDrill ? "Open team" : "View cases";
      button.addEventListener("click", () => row.canDrill
        ? openTeam(row.id, row.displayName || row.id)
        : openDetail(row.id, row.displayName || row.id));
      cell.append(button);
    } else if (column.key === "counts") {
      cell.append(renderBreakdown(row.counts || {}, state.card));
    }
    tr.append(cell);
  });
  return tr;
}

function renderDetail() {
  if (!state.detail) return;
  elements.detailTitle.textContent = state.selectedUser?.displayName || "Assigned cases";
  const columns = detailColumns(state.card);
  elements.detailHead.replaceChildren(makeRow(columns.map((column) => headerCell(column.label)), "tr"));
  elements.detailBody.replaceChildren();
  if (!state.detail.length) {
    elements.detailBody.append(makeEmptyRow(columns.length, "No data available in table"));
    return;
  }
  state.detail.forEach((row) => {
    elements.detailBody.append(renderDetailRow(row, columns));
    if (state.card !== "enrollment") {
      (row.overduePrograms || []).forEach((program) => elements.detailBody.append(renderOverdueSubrow(program, columns.length)));
    }
  });
}

function renderDetailRow(row, columns) {
  const tr = document.createElement("tr");
  const statusClass = detailRowStatusClass(row);
  if (statusClass) tr.classList.add(statusClass);
  columns.forEach((column) => {
    const td = document.createElement("td");
    switch (column.key) {
      case "caseId": {
        const link = document.createElement("button");
        link.className = "case-link";
        link.type = "button";
        link.textContent = row.caseId || "";
        link.addEventListener("click", () => openCase(row));
        td.append(link);
        break;
      }
      case "caseName": td.textContent = row.caseName || ""; break;
      case "memberName": td.textContent = row.memberName || ""; break;
      case "programs": td.append(renderPrograms(row.programsAssigned)); break;
      case "assessment": td.append(statusPill(row.assessmentStatus, assessmentClass(row.assessmentStatus))); break;
      case "scLevel": td.textContent = row.scLevel || "Unknown"; break;
      case "ispStartDate": td.textContent = formatDate(row.ispStartDate); break;
      case "ispEndDate": td.textContent = formatDate(row.ispEndDate); break;
      default: td.textContent = "";
    }
    tr.append(td);
  });
  return tr;
}

function renderOverdueSubrow(program, columnCount) {
  const tr = document.createElement("tr");
  tr.className = "subrow";
  const td = document.createElement("td");
  td.colSpan = columnCount;
  td.textContent = `Overdue program: ${program.program || program.name || "Program"}  /  Due ${formatDate(program.dueDate || program.endDate)}`;
  tr.append(td);
  return tr;
}

function renderPrograms(programs) {
  const list = document.createElement("div");
  list.className = "program-list";
  (programs || []).forEach((program) => {
    const item = document.createElement("div");
    const name = document.createElement("span");
    name.className = "program-name";
    name.textContent = program.name || program.code || "Program";
    const meta = document.createElement("span");
    meta.className = "program-meta";
    meta.textContent = [program.status, formatDate(program.startDate), formatDate(program.endDate)].filter(Boolean).join(" / ");
    item.append(name, meta);
    list.append(item);
  });
  if (!programs?.length) list.textContent = "None recorded";
  return list;
}

function renderBreakdown(counts, card) {
  const container = document.createElement("div");
  container.className = "count-breakdown";
  if (card === "sc-level") {
    container.classList.add("member-level-breakdown");
    const levels = [
      ["Level 1", counts.level1, "level-one"],
      ["1NF", counts.level1NF, "level-one-nf"],
      ["Level 2", counts.level2, "level-two"],
      ["Level 3", counts.level3, "level-three"],
      ["Unknown", counts.unknown, "level-unknown"]
    ];
    levels.forEach(([label, count, levelClass]) => {
      const badge = document.createElement("span");
      badge.className = `member-level-badge ${levelClass}`;
      badge.setAttribute("aria-label", `${label}: ${formatNumber(count)} members`);
      const labelElement = document.createElement("span");
      labelElement.className = "member-level-label";
      labelElement.textContent = label;
      const countElement = document.createElement("strong");
      countElement.textContent = formatNumber(count);
      badge.append(labelElement, countElement);
      container.append(badge);
    });
    return container;
  }

  let entries;
  if (card === "enrollment") {
    entries = [["Cases", counts.cases, "metric-neutral"]];
  } else if (card === "duration") {
    entries = [
      ["Overdue", counts.overdue, "metric-overdue"],
      ["Nearing", counts.nearingDue, "metric-nearing"],
      ["Compliant", counts.compliant, "metric-compliant"]
    ];
  }
  entries.forEach(([label, value, tone]) => {
    const span = document.createElement("span");
    span.className = `metric-badge ${tone}`;
    const labelElement = document.createElement("span");
    labelElement.className = "metric-label";
    labelElement.textContent = label;
    const countElement = document.createElement("strong");
    countElement.textContent = formatNumber(value);
    span.append(labelElement, countElement);
    container.append(span);
  });
  return container;
}

function teamColumns(card) {
  const metricLabel = card === "enrollment" ? "Assigned cases" : card === "duration" ? "Member programs" : "Members by level";
  return [{ key: "person", label: "Team member" }, { key: "counts", label: metricLabel }, { key: "action", label: "" }];
}

function detailColumns(card) {
  if (card === "sc-level") return [
    { key: "caseId", label: "Case ID" }, { key: "caseName", label: "Case name" },
    { key: "memberName", label: "Member" }, { key: "assessment", label: "Assessment status" },
    { key: "scLevel", label: "SC level" }, { key: "ispStartDate", label: "ISP start" },
    { key: "ispEndDate", label: "ISP end" }, { key: "programs", label: "Programs assigned" }
  ];
  return [
    { key: "caseId", label: "Case ID" }, { key: "caseName", label: "Case name" },
    { key: "memberName", label: "Member" }, { key: "programs", label: "Programs assigned" }
  ];
}

function openCase(row) {
  const payload = {
    page: "CmCase",
    options: {
      externalMember: { memberId: row.memberId, systemId: String(row.systemId) },
      caseId: row.caseId,
      tab: "careplan"
    }
  };
  if (window.dashboard?.publish) {
    window.dashboard.publish("cca.navigate", payload);
  } else {
    showNotice(`Case ${row.caseId} is ready to open in CCA when this card is hosted by the CCA shell.`, "info");
  }
}

function statusCount(label, value, className) {
  const item = document.createElement("span");
  item.className = `status-item ${className}`;
  item.textContent = `${label} ${formatNumber(value)}`;
  return item;
}

function statusPill(value, className) {
  const pill = document.createElement("span");
  pill.className = `status-pill ${className}`;
  pill.textContent = value || "Unknown";
  return pill;
}

function assessmentClass(value) {
  const normalized = String(value || "").toLowerCase();
  if (normalized.includes("rejected") || normalized.includes("overdue")) return "pill-overdue";
  if (normalized.includes("accepted") || normalized.includes("compliant")) return "pill-compliant";
  if (normalized.includes("near")) return "pill-near";
  return "pill-neutral";
}

function detailRowStatusClass(row) {
  const status = String(row.assessmentStatus || row.submissionStatus || row.status || "").toLowerCase();
  if (status.includes("rejected") || status.includes("overdue") || row.overduePrograms?.length) return "detail-status-rejected";
  if (status.includes("accepted") || status.includes("compliant")) return "detail-status-accepted";
  if (status.includes("near") || status.includes("pending") || status.includes("unknown")) return "detail-status-other";
  return "";
}

function makeRow(cells, tagName) {
  const row = document.createElement(tagName);
  cells.forEach((cell) => row.append(cell));
  return row;
}

function headerCell(label) {
  const cell = document.createElement("th");
  cell.scope = "col";
  cell.textContent = label;
  return cell;
}

function makeEmptyRow(columnCount, message) {
  const row = document.createElement("tr");
  const cell = document.createElement("td");
  cell.className = "empty-row";
  cell.colSpan = columnCount;
  cell.textContent = message;
  row.append(cell);
  return row;
}

function showNotice(message, level) {
  elements.notice.hidden = !message;
  elements.notice.textContent = message;
  elements.notice.dataset.level = level;
  if (level === "error") elements.notice.style.borderLeftColor = "var(--red)";
  else if (level === "warning") elements.notice.style.borderLeftColor = "var(--gold)";
  else elements.notice.style.borderLeftColor = "var(--blue)";
}

function number(value) {
  return Number.isFinite(Number(value)) ? Number(value) : 0;
}

function formatNumber(value) {
  return number(value).toLocaleString();
}

function formatDate(value) {
  if (!value) return "";
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? String(value) : new Intl.DateTimeFormat(undefined, { dateStyle: "medium" }).format(date);
}

function formatDateTime(value) {
  if (!value) return "Today";
  const date = new Date(value);
  return Number.isNaN(date.valueOf()) ? String(value) : new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(date);
}

function createDemoData() {
  const rootId = "0-demo";
  const detail = {
    "0-demo": [
      { caseId: "CM-DEMO-1042", caseName: "Care coordination follow-up", memberId: "DEMO-8001", systemId: 2, memberName: "Sample Member A", programsAssigned: [{ name: "Community Support", status: "Active", startDate: "2026-03-05", endDate: "2026-12-10" }], overduePrograms: [], assessmentStatus: "In compliant", scLevel: "1NF", ispStartDate: "2026-05-01", ispEndDate: "2027-05-01" },
      { caseId: "CM-DEMO-1088", caseName: "Annual service review", memberId: "DEMO-8002", systemId: 2, memberName: "Sample Member B", programsAssigned: [{ name: "Health Coaching", status: "Active", startDate: "2026-02-01", endDate: "2026-10-30" }], overduePrograms: [{ program: "Health Coaching", dueDate: "2026-10-30" }], assessmentStatus: "Near due", scLevel: "2", ispStartDate: "2026-04-15", ispEndDate: "2027-04-15" }
    ],
    "0-avery": [
      { caseId: "CM-DEMO-1120", caseName: "Member needs assessment", memberId: "DEMO-8003", systemId: 2, memberName: "Sample Member C", programsAssigned: [{ name: "Family Wellness", status: "Active", startDate: "2026-04-20", endDate: "2026-12-01" }], overduePrograms: [], assessmentStatus: "Overdue", scLevel: "1", ispStartDate: "2026-01-10", ispEndDate: "2027-01-10" }
    ]
  };
  const rootRows = [
    { id: rootId, displayName: "Jordan Lee", rowType: "Self", counts: { cases: 2, overdue: 1, nearingDue: 1, compliant: 2, level1: 0, level1NF: 1, level2: 1, level3: 0, unknown: 0 } },
    { id: "0-avery", displayName: "Avery Morgan", rowType: "Team", memberCount: 2, canDrill: true, counts: { cases: 3, overdue: 1, nearingDue: 1, compliant: 2, level1: 1, level1NF: 1, level2: 1, level3: 0, unknown: 0 } },
    { id: "0-sam", displayName: "Sam Patel", rowType: "User", canDrill: false, counts: { cases: 1, overdue: 0, nearingDue: 1, compliant: 1, level1: 1, level1NF: 0, level2: 0, level3: 0, unknown: 0 } }
  ];
  const teamRows = [
    { id: "0-avery", displayName: "Avery Morgan", rowType: "Self", counts: { cases: 1, overdue: 0, nearingDue: 1, compliant: 1, level1: 0, level1NF: 1, level2: 0, level3: 0, unknown: 0 } },
    { id: "0-riley", displayName: "Riley Chen", rowType: "User", canDrill: false, counts: { cases: 2, overdue: 1, nearingDue: 0, compliant: 1, level1: 1, level1NF: 0, level2: 1, level3: 0, unknown: 0 } }
  ];
  const makeSummary = (rows) => ({
    context: { callerUserId: rootId, viewRootId: rows[0].id, breadcrumb: [{ userId: rootId, displayName: "Jordan Lee" }] },
    rows,
    totals: rows.reduce((total, row) => {
      Object.keys(row.counts).forEach((key) => { total[key] = (total[key] || 0) + row.counts[key]; });
      return total;
    }, {}),
    asOf: new Date().toISOString(), isPartial: false, warnings: []
  });
  const summaries = {
    enrollment: makeSummary(rootRows),
    duration: makeSummary(rootRows),
    "sc-level": makeSummary(rootRows)
  };
  const teamSummaries = {
    "0-avery": { enrollment: makeSummary(teamRows), duration: makeSummary(teamRows), "sc-level": makeSummary(teamRows) }
  };
  return { rootId, summaries, teamSummaries, details: detail };
}