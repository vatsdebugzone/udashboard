using System.ComponentModel.DataAnnotations;

namespace Dashboard.Api;

public sealed class AuthOptions
{
    public const string SectionName = "Auth";

    [Required]
    public string Issuer { get; set; } = string.Empty;

    [Required]
    public string Audience { get; set; } = string.Empty;

    [Required]
    public string Subject { get; set; } = string.Empty;

    [Range(1, 60)]
    public int TokenLifetimeMinutes { get; set; } = 5;
}

public sealed class CareAdvanceOptions
{
    public const string SectionName = "CareAdvance";

    [Required, Url]
    public string BaseUrl { get; set; } = string.Empty;

    [Required]
    public string UserApiPath { get; set; } = string.Empty;

    [Required]
    public string ConceptApiPath { get; set; } = string.Empty;

    [Range(1, 300)]
    public int TimeoutSeconds { get; set; } = 30;

    [Range(1, 100)]
    public int UserPageSize { get; set; } = 100;
}

public sealed class DashboardOptions
{
    public const string SectionName = "Dashboard";

    [Range(1, 1440)]
    public int CacheMinutes { get; set; } = 10;

    [Range(1, 50)]
    public int MaxParallelSqlCalls { get; set; } = 5;

    [Range(1, 50)]
    public int MaxParallelConceptCalls { get; set; } = 10;

    [Range(1, 10)]
    public int MaxTeamDepth { get; set; } = 10;

    [Range(1, 100)]
    public int UserPageSize { get; set; } = 100;

    [Required]
    public string AssignmentStoredProcedure { get; set; } = "dbo.chc_GetAssignedCasesMembers";

    [Required]
    public string ConfigurationTable { get; set; } = "dbo.chct_Dashboard_Config";

    [Required]
    public string DurationRulesTable { get; set; } = "dbo.chct_Dashboard_Program_Duration";

    public int? ScLevelConceptId { get; set; }
    public int? IspStartDateConceptId { get; set; }
    public int? IspEndDateConceptId { get; set; }
    public int? AssessmentDateConceptId { get; set; }

    public string? AssessmentDateSource { get; set; }

    [Required]
    public string ActiveProgramValue { get; set; } = "Active";

    [Required]
    public string DateFormat { get; set; } = "M/d/yyyy";

    [Required]
    public string BusinessTimeZone { get; set; } = "America/Chicago";
}

public sealed class SecurityOptions
{
    public const string SectionName = "Security";

    [MinLength(1)]
    public string[] FrameAncestors { get; set; } = ["'self'"];

    public bool RequireHttps { get; set; } = true;
}

public sealed class CcaOptions
{
    public const string SectionName = "Cca";

    [Required, Url]
    public string ParentOrigin { get; set; } = string.Empty;

    [Required]
    public string CardPath { get; set; } = "/dashboard";
}