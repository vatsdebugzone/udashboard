using Dashboard.Application;
using Dashboard.Domain;
using Microsoft.AspNetCore.Mvc;

namespace Dashboard.Api;

public static class DashboardEndpoints
{
    public static IEndpointRouteBuilder MapDashboardEndpoints(this IEndpointRouteBuilder endpoints)
    {
        var group = endpoints.MapGroup("/api/dashboard").WithTags("Dashboard");

        MapCard(group, "enrollment", DashboardCard.Enrollment);
        MapCard(group, "duration", DashboardCard.Duration);
        MapCard(group, "sc-level", DashboardCard.ScLevel);

        return endpoints;
    }

    private static void MapCard(RouteGroupBuilder group, string route, DashboardCard card)
    {
        group.MapGet($"/{route}/summary", async (
            [FromQuery] string callerUserId,
            [FromQuery] string viewRootId,
            IDashboardDataService service,
            CancellationToken cancellationToken) =>
        {
            if (string.IsNullOrWhiteSpace(callerUserId) || string.IsNullOrWhiteSpace(viewRootId))
            {
                return Results.Problem(title: "Unable to identify user", statusCode: StatusCodes.Status400BadRequest);
            }

            try
            {
                _ = ParsedUserId.Parse(callerUserId);
                _ = ParsedUserId.Parse(viewRootId);

                if (callerUserId.Equals("0-demo", StringComparison.OrdinalIgnoreCase))
                    return Results.Ok(CreateDemoSummary(card, callerUserId, viewRootId));

                return Results.Ok(await service.GetSummaryAsync(card, callerUserId, viewRootId, cancellationToken));
            }
            catch (FormatException)
            {
                return Results.Problem(title: "Unable to identify user", statusCode: StatusCodes.Status400BadRequest);
            }
            catch (UnauthorizedAccessException)
            {
                return Results.Problem(title: "Requested team is outside the caller's hierarchy", statusCode: StatusCodes.Status403Forbidden);
            }
            catch (InvalidOperationException exception)
            {
                return Results.Problem(title: "Dashboard configuration error", detail: exception.Message, statusCode: StatusCodes.Status503ServiceUnavailable);
            }
        })
        .WithName($"Get{route.Replace("-", string.Empty, StringComparison.Ordinal)}Summary")
        .Produces<DashboardSummaryResponse>()
        .ProducesProblem(StatusCodes.Status400BadRequest)
        .ProducesProblem(StatusCodes.Status403Forbidden)
        .ProducesProblem(StatusCodes.Status503ServiceUnavailable);

        group.MapGet($"/{route}/users/{{userId}}/detail", async (
            string userId,
            [FromQuery] string callerUserId,
            IDashboardDataService service,
            CancellationToken cancellationToken) =>
        {
            if (string.IsNullOrWhiteSpace(callerUserId))
            {
                return Results.Problem(title: "Unable to identify user", statusCode: StatusCodes.Status400BadRequest);
            }

            try
            {
                _ = ParsedUserId.Parse(callerUserId);
                _ = ParsedUserId.Parse(userId);

                if (callerUserId.Equals("0-demo", StringComparison.OrdinalIgnoreCase))
                    return Results.Ok(CreateDemoDetail(card, callerUserId, userId));

                return Results.Ok(await service.GetDetailAsync(card, callerUserId, userId, cancellationToken));
            }
            catch (FormatException)
            {
                return Results.Problem(title: "Unable to identify user", statusCode: StatusCodes.Status400BadRequest);
            }
            catch (UnauthorizedAccessException)
            {
                return Results.Problem(title: "Requested user is outside the caller's hierarchy", statusCode: StatusCodes.Status403Forbidden);
            }
            catch (InvalidOperationException exception)
            {
                return Results.Problem(title: "Dashboard configuration error", detail: exception.Message, statusCode: StatusCodes.Status503ServiceUnavailable);
            }
        })
        .WithName($"Get{route.Replace("-", string.Empty, StringComparison.Ordinal)}UserDetail")
        .Produces<DashboardDetailResponse>()
        .ProducesProblem(StatusCodes.Status400BadRequest)
        .ProducesProblem(StatusCodes.Status403Forbidden)
        .ProducesProblem(StatusCodes.Status503ServiceUnavailable);
    }

    private static DashboardSummaryResponse CreateDemoSummary(DashboardCard card, string callerUserId, string viewRootId)
    {
        var rootId = viewRootId.Equals("0-demo", StringComparison.OrdinalIgnoreCase) ? "0-demo" : viewRootId;
        var rows = rootId == "0-demo"
            ? card == DashboardCard.ScLevel
                ? new[]
                {
                    new SummaryRow("0-demo", "Jordan Lee", "Self", new SummaryCounts(Level1: 0, Level1NF: 1, Level2: 1, Level3: 0, Unknown: 0), null, false),
                    new SummaryRow("0-avery", "Avery Morgan", "Team", new SummaryCounts(Level1: 1, Level1NF: 1, Level2: 1, Level3: 0, Unknown: 0), 2, true),
                    new SummaryRow("0-sam", "Sam Patel", "User", new SummaryCounts(Level1: 2, Level1NF: 0, Level2: 0, Level3: 0, Unknown: 0), null, false)
                }
                : new[]
                {
                    new SummaryRow("0-demo", "Jordan Lee", "Self", new SummaryCounts(2, 2, 3, 5), null, false),
                    new SummaryRow("0-avery", "Avery Morgan", "Team", new SummaryCounts(3, 3, 2, 4), 2, true),
                    new SummaryRow("0-sam", "Sam Patel", "User", new SummaryCounts(1, 1, 2, 3), null, false)
                }
            : card == DashboardCard.ScLevel
                ? new[]
                {
                    new SummaryRow(viewRootId, "Avery Morgan", "Self", new SummaryCounts(Level1: 1, Level1NF: 1, Level2: 0, Level3: 0, Unknown: 0), null, false),
                    new SummaryRow("0-riley", "Riley Chen", "User", new SummaryCounts(Level1: 1, Level1NF: 0, Level2: 1, Level3: 1, Unknown: 0), null, false)
                }
                : new[]
                {
                    new SummaryRow(viewRootId, "Avery Morgan", "Self", new SummaryCounts(1, 1, 1, 2), null, false),
                    new SummaryRow("0-riley", "Riley Chen", "User", new SummaryCounts(2, 2, 1, 2), null, false)
                };

        var totals = card switch
        {
            DashboardCard.Enrollment => new SummaryCounts(Cases: rows.Sum(row => row.Counts.Cases)),
            DashboardCard.Duration => new SummaryCounts(
                Overdue: rows.Sum(row => row.Counts.Overdue),
                NearingDue: rows.Sum(row => row.Counts.NearingDue),
                Compliant: rows.Sum(row => row.Counts.Compliant)),
            DashboardCard.ScLevel => new SummaryCounts(Level1: 3, Level1NF: 2, Level2: 2, Level3: 1, Unknown: 0),
            _ => new SummaryCounts()
        };

        var breadcrumb = rootId == "0-demo"
            ? new[] { new BreadcrumbItem("0-demo", "Jordan Lee") }
            : new[]
            {
                new BreadcrumbItem("0-demo", "Jordan Lee"),
                new BreadcrumbItem(viewRootId, "Avery Morgan")
            };

        return new DashboardSummaryResponse(
            new SummaryContext(callerUserId, viewRootId, breadcrumb),
            rows,
            totals,
            DateTimeOffset.UtcNow,
            false,
            []);
    }

    private static DashboardDetailResponse CreateDemoDetail(DashboardCard card, string callerUserId, string userId)
    {
        var (displayName, rows) = userId switch
        {
            "0-avery" => (
                "Avery Morgan",
                new[]
                {
                    new DashboardDetailRow("CM-DEMO-1120", "Member needs assessment", "2", "DEMO-8003", "Sample Member C",
                        [new ProgramDetail("Family Wellness", "Family Wellness", "Active", new DateOnly(2026, 4, 20), new DateOnly(2026, 12, 1), "Nearing Due")],
                        card == DashboardCard.Duration ? [new OverdueProgramDetail("Family Wellness", new DateOnly(2026, 12, 1))] : [],
                        card == DashboardCard.ScLevel ? "Overdue" : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 4, 1) : null,
                        card == DashboardCard.ScLevel ? "1" : "Unknown",
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 1, 10) : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2027, 1, 10) : null,
                        false)
                }),
            "0-sam" => (
                "Sam Patel",
                new[]
                {
                    new DashboardDetailRow("CM-DEMO-1144", "Care plan check-in", "2", "DEMO-8004", "Sample Member D",
                        [new ProgramDetail("Community Support", "Community Support", "Active", new DateOnly(2026, 6, 12), new DateOnly(2027, 6, 12), "Compliant")],
                        [], card == DashboardCard.ScLevel ? "In compliant" : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 10, 1) : null,
                        card == DashboardCard.ScLevel ? "1" : "Unknown",
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 6, 12) : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2027, 6, 12) : null,
                        false)
                }),
            "0-riley" => (
                "Riley Chen",
                new[]
                {
                    new DashboardDetailRow("CM-DEMO-1188", "Behavioral health review", "2", "DEMO-8005", "Sample Member E",
                        [new ProgramDetail("Aftercare", "Aftercare", "Active", new DateOnly(2026, 8, 1), new DateOnly(2026, 12, 1), "Nearing Due")],
                        card == DashboardCard.Duration ? [new OverdueProgramDetail("Aftercare", new DateOnly(2026, 12, 1))] : [],
                        card == DashboardCard.ScLevel ? "Near due" : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 9, 1) : null,
                        card == DashboardCard.ScLevel ? "3" : "Unknown",
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 7, 1) : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2027, 7, 1) : null,
                        false)
                }),
            _ => (
                "Jordan Lee",
                new[]
                {
                    new DashboardDetailRow("CM-DEMO-1042", "Care coordination follow-up", "2", "DEMO-8001", "Sample Member A",
                        [new ProgramDetail("Community Support", "Community Support", "Active", new DateOnly(2026, 3, 5), new DateOnly(2026, 12, 10), "Compliant")],
                        [], card == DashboardCard.ScLevel ? "In compliant" : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 10, 1) : null,
                        card == DashboardCard.ScLevel ? "1NF" : "Unknown",
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 5, 1) : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2027, 5, 1) : null,
                        false),
                    new DashboardDetailRow("CM-DEMO-1088", "Annual service review", "2", "DEMO-8002", "Sample Member B",
                        [new ProgramDetail("Health Coaching", "Health Coaching", "Active", new DateOnly(2026, 2, 1), new DateOnly(2026, 10, 30), "Overdue")],
                        card == DashboardCard.Duration ? [new OverdueProgramDetail("Health Coaching", new DateOnly(2026, 10, 30))] : [],
                        card == DashboardCard.ScLevel ? "Near due" : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 8, 1) : null,
                        card == DashboardCard.ScLevel ? "2" : "Unknown",
                        card == DashboardCard.ScLevel ? new DateOnly(2026, 4, 15) : null,
                        card == DashboardCard.ScLevel ? new DateOnly(2027, 4, 15) : null,
                        false)
                })
        };

        var visibleRows = card == DashboardCard.Duration
            ? rows.Where(row => row.OverduePrograms.Count > 0).ToArray()
            : rows;

        return new DashboardDetailResponse(userId, displayName, visibleRows, false, []);
    }
}