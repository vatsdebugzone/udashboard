using Dashboard.Api;
using Dashboard.Application;
using Dashboard.Infrastructure;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMemoryCache();
builder.Services.AddOptions<AuthOptions>().BindConfiguration(AuthOptions.SectionName);
builder.Services.AddOptions<CareAdvanceOptions>()
    .BindConfiguration(CareAdvanceOptions.SectionName)
    .ValidateDataAnnotations()
    .ValidateOnStart();
builder.Services.AddOptions<DashboardOptions>()
    .BindConfiguration(DashboardOptions.SectionName)
    .ValidateDataAnnotations()
    .ValidateOnStart();
builder.Services.AddOptions<SecurityOptions>()
    .BindConfiguration(SecurityOptions.SectionName)
    .ValidateDataAnnotations()
    .ValidateOnStart();
builder.Services.AddOptions<CcaOptions>()
    .BindConfiguration(CcaOptions.SectionName)
    .ValidateDataAnnotations()
    .ValidateOnStart();
builder.Services.AddSingleton<IDashboardConfigurationRepository, DashboardConfigurationRepository>();
builder.Services.AddScoped<IAssignmentRepository, AssignmentRepository>();
builder.Services.AddScoped<IDashboardSettingsProvider, DashboardSettingsProvider>();
builder.Services.AddScoped<ITokenService, CareAdvanceTokenService>();
builder.Services.AddHttpClient<ICareAdvanceClient, CareAdvanceClient>();
builder.Services.AddScoped<IDashboardDataService, DashboardDataService>();

var app = builder.Build();

app.UseHttpsRedirection();
var frameAncestors = builder.Configuration.GetSection("Security:FrameAncestors").Get<string[]>() ?? ["'self'"];
app.Use(async (context, next) =>
{
    context.Response.Headers.CacheControl = "no-store";
    context.Response.Headers.ContentSecurityPolicy =
        $"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors {string.Join(' ', frameAncestors)}";
    await next();
});

app.UseDefaultFiles();
app.UseStaticFiles();
app.MapGet("/health", () => Results.Ok(new { status = "healthy" }));
app.MapDashboardEndpoints();

var dashboardHtml = await File.ReadAllTextAsync(Path.Combine(app.Environment.WebRootPath!, "index.html"));
MapCcaCard("ProgramEnrollmentApi", dashboardHtml);
MapCcaCard("ProgramDurationApi", dashboardHtml);
MapCcaCard("ScLevelApi", dashboardHtml);

app.Run();

void MapCcaCard(string endpoint, string html)
{
    app.MapGet($"/api/{endpoint}", (HttpRequest request) =>
    {
        var userId = request.Query["externalUserId"].FirstOrDefault()
            ?? request.Query["userId"].FirstOrDefault();
        var bootstrap = string.IsNullOrWhiteSpace(userId)
            ? html
            : html.Replace("</head>", $"<meta name=\"dashboard-user-id\" content=\"{System.Net.WebUtility.HtmlEncode(userId)}\"></head>", StringComparison.OrdinalIgnoreCase);
        return Results.Content(bootstrap, "text/html; charset=utf-8");
    })
    .WithTags("CCA Cards")
    .WithName(endpoint)
    .Produces(StatusCodes.Status200OK, contentType: "text/html");
}
