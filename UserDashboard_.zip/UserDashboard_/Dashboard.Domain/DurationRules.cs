namespace Dashboard.Domain;

public enum DurationBasis
{
    None,
    StartDate,
    EndDate,
    EligibilityOnly
}

public enum DurationStatus
{
    Compliant,
    NearingDue,
    Overdue,
    NotApplicable,
    NotActive,
    Unknown
}

public sealed record ProgramDurationRule(
    string ProgramName,
    DurationBasis Basis,
    int? CompliantFrom,
    int? CompliantTo,
    int? NearDueFrom,
    int? NearDueTo,
    int? OverdueAfterDays = null,
    bool IsBusinessDate = false);

public sealed record DurationAssessment(DurationStatus Status, int? Days);

public static class DurationRuleEngine
{
    public static DurationAssessment Classify(
        ProgramDurationRule rule,
        bool isActive,
        DateOnly? startDate,
        DateOnly? endDate,
        DateOnly today,
        IReadOnlySet<DateOnly>? holidays = null)
    {
        if (!isActive)
        {
            return new(DurationStatus.NotActive, null);
        }

        if (rule.Basis == DurationBasis.None)
        {
            return new(DurationStatus.NotApplicable, null);
        }

        if (rule.Basis == DurationBasis.EligibilityOnly)
        {
            return new(DurationStatus.Compliant, null);
        }

        if (endDate is not null && endDate < today)
        {
            return new(DurationStatus.Overdue, DaysBetween(today, endDate.Value, rule.IsBusinessDate, holidays));
        }

        var days = rule.Basis switch
        {
            DurationBasis.StartDate when startDate is not null =>
                DaysBetween(startDate.Value, today, rule.IsBusinessDate, holidays),
            DurationBasis.EndDate when endDate is not null =>
                DaysBetween(today, endDate.Value, rule.IsBusinessDate, holidays),
            _ => (int?)null
        };

        if (days is null)
        {
            return new(DurationStatus.Unknown, null);
        }

        if (rule.Basis == DurationBasis.StartDate &&
            ((rule.OverdueAfterDays is not null && days > rule.OverdueAfterDays) ||
             (rule.OverdueAfterDays is null && rule.NearDueTo is not null && days > rule.NearDueTo)))
        {
            return new(DurationStatus.Overdue, days);
        }

        if (IsWithin(days.Value, rule.NearDueFrom, rule.NearDueTo))
        {
            return new(DurationStatus.NearingDue, days);
        }

        if (IsWithin(days.Value, rule.CompliantFrom, rule.CompliantTo))
        {
            return new(DurationStatus.Compliant, days);
        }

        return new(DurationStatus.Unknown, days);
    }

    private static bool IsWithin(int value, int? from, int? to) =>
        (from is null || value >= from) && (to is null || value <= to);

    private static int DaysBetween(
        DateOnly start,
        DateOnly end,
        bool businessDays,
        IReadOnlySet<DateOnly>? holidays)
    {
        if (!businessDays)
        {
            return end.DayNumber - start.DayNumber;
        }

        var direction = end >= start ? 1 : -1;
        var count = 0;
        for (var day = start.AddDays(direction); direction > 0 ? day <= end : day >= end; day = day.AddDays(direction))
        {
            if (day.DayOfWeek is not DayOfWeek.Saturday and not DayOfWeek.Sunday &&
                (holidays is null || !holidays.Contains(day)))
            {
                count += direction;
            }
        }

        return count;
    }
}

public enum AssessmentStatus
{
    InCompliance,
    NearDue,
    Overdue,
    NoAssessment,
    UnknownLevel
}

public sealed record AssessmentAssessment(AssessmentStatus Status, int? DaysSinceLastAssessment);

public static class AssessmentRuleEngine
{
    public static AssessmentAssessment Evaluate(string? scLevel, DateOnly? lastAssessmentDate, DateOnly today)
    {
        var (frequency, compliantThrough, nearDueThrough) = NormalizeLevel(scLevel) switch
        {
            "1" or "1NF" => (90, 75, 90),
            "2" or "3" => (180, 165, 180),
            _ => (0, 0, 0)
        };

        if (frequency == 0)
        {
            return new(AssessmentStatus.UnknownLevel, null);
        }

        if (lastAssessmentDate is null)
        {
            return new(AssessmentStatus.NoAssessment, null);
        }

        var days = Math.Max(0, today.DayNumber - lastAssessmentDate.Value.DayNumber);
        var status = days <= compliantThrough
            ? AssessmentStatus.InCompliance
            : days <= nearDueThrough
                ? AssessmentStatus.NearDue
                : AssessmentStatus.Overdue;

        return new(status, days);
    }

    private static string NormalizeLevel(string? scLevel) =>
        string.IsNullOrWhiteSpace(scLevel) ? string.Empty : scLevel.Trim().ToUpperInvariant();
}