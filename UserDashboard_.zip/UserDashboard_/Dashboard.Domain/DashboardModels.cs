using System.Globalization;

namespace Dashboard.Domain;

public enum DashboardCard
{
    Enrollment,
    Duration,
    ScLevel
}

public sealed record ParsedUserId(int SystemId, string ExternalId)
{
    public static ParsedUserId Parse(string? userId)
    {
        var separator = userId?.IndexOf('-') ?? -1;
        if (separator <= 0 || separator == userId!.Length - 1 ||
            !int.TryParse(userId[..separator], NumberStyles.None, CultureInfo.InvariantCulture, out var systemId))
        {
            throw new FormatException("Unable to identify user. Expected [integer]-[external Id].");
        }

        return new ParsedUserId(systemId, userId[(separator + 1)..]);
    }
}

public sealed record MemberKey(string SystemId, string MemberId)
{
    public string CareAdvanceId => $"{SystemId}-{MemberId}";
}

public sealed record AssignedCase(
    string UserId,
    string CaseId,
    string CaseName,
    string SystemId,
    string MemberId,
    string MemberName);

public sealed record TeamUser(
    string Id,
    string DisplayName,
    bool Active,
    bool OnHold,
    int SubordinateCount,
    IReadOnlyList<TeamUser> Subordinates);

public sealed record ProgramDefinition(
    string Name,
    int StatusConceptId,
    int? StartDateConceptId,
    int? EndDateConceptId,
    ProgramDurationRule DurationRule);

public sealed record DashboardConfiguration(
    string Issuer,
    string Audience,
    string Subject,
    string CareAdvanceBaseUrl,
    string UserApiPath,
    string ConceptApiPath,
    int TimeoutSeconds,
    int UserPageSize,
    int CacheMinutes,
    int MaxParallelSqlCalls,
    int MaxParallelConceptCalls,
    int MaxTeamDepth,
    int? ScLevelConceptId,
    int? IspStartDateConceptId,
    int? IspEndDateConceptId,
    int? AssessmentDateConceptId,
    string ActiveProgramValue,
    string DateFormat,
    IReadOnlySet<DateOnly> Holidays,
    IReadOnlyList<ProgramDefinition> Programs);

public sealed record BreadcrumbItem(string UserId, string DisplayName);

public sealed record SummaryContext(
    string CallerUserId,
    string ViewRootId,
    IReadOnlyList<BreadcrumbItem> Breadcrumb);

public sealed record SummaryCounts(
    int Cases = 0,
    int Overdue = 0,
    int NearingDue = 0,
    int Compliant = 0,
    int Level1 = 0,
    int Level1NF = 0,
    int Level2 = 0,
    int Level3 = 0,
    int Unknown = 0);

public sealed record SummaryRow(
    string Id,
    string DisplayName,
    string RowType,
    SummaryCounts Counts,
    int? MemberCount,
    bool CanDrill);

public sealed record DashboardSummaryResponse(
    SummaryContext Context,
    IReadOnlyList<SummaryRow> Rows,
    SummaryCounts Totals,
    DateTimeOffset AsOf,
    bool IsPartial,
    IReadOnlyList<string> Warnings);

public sealed record ProgramDetail(
    string Code,
    string Name,
    string Status,
    DateOnly? StartDate,
    DateOnly? EndDate,
    string? DurationStatus);

public sealed record OverdueProgramDetail(string Program, DateOnly? DueDate);

public sealed record DashboardDetailRow(
    string CaseId,
    string CaseName,
    string SystemId,
    string MemberId,
    string MemberName,
    IReadOnlyList<ProgramDetail> ProgramsAssigned,
    IReadOnlyList<OverdueProgramDetail> OverduePrograms,
    string? AssessmentStatus,
    DateOnly? LastAssessmentDate,
    string ScLevel,
    DateOnly? IspStartDate,
    DateOnly? IspEndDate,
    bool ConceptsUnavailable);

public sealed record DashboardDetailResponse(
    string UserId,
    string DisplayName,
    IReadOnlyList<DashboardDetailRow> Rows,
    bool IsPartial,
    IReadOnlyList<string> Warnings);