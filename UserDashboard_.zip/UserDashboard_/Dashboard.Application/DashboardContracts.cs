using Dashboard.Domain;

namespace Dashboard.Application;

public interface IAssignmentRepository
{
    Task<IReadOnlyList<AssignedCase>> GetAssignedCasesAsync(string userId, CancellationToken cancellationToken);
}

public interface IDashboardDataService
{
    Task<DashboardSummaryResponse> GetSummaryAsync(
        DashboardCard card,
        string callerUserId,
        string viewRootId,
        CancellationToken cancellationToken);

    Task<DashboardDetailResponse> GetDetailAsync(
        DashboardCard card,
        string callerUserId,
        string userId,
        CancellationToken cancellationToken);
}

public interface IDashboardSettingsProvider
{
    Task<Dashboard.Domain.DashboardConfiguration> GetAsync(CancellationToken cancellationToken);
}

public interface ICareAdvanceClient
{
    Task<Dashboard.Domain.TeamUser> GetTeamTreeAsync(
        string rootUserId,
        Dashboard.Domain.DashboardConfiguration configuration,
        CancellationToken cancellationToken);

    Task<IReadOnlyDictionary<int, string?>> GetConceptValuesAsync(
        Dashboard.Domain.MemberKey member,
        IEnumerable<int> conceptIds,
        Dashboard.Domain.DashboardConfiguration configuration,
        CancellationToken cancellationToken);
}

public interface ITokenService
{
    Task<string> GetBearerTokenAsync(
        Dashboard.Domain.DashboardConfiguration configuration,
        CancellationToken cancellationToken);
}