namespace Dashboard.Application;

public sealed record ConfigRow(string Filter, string Parameter, string Value);

public sealed record ProgramDurationRow(
    string Program,
    string? Duration,
    string? Basis,
    int? CompliantFrom,
    int? CompliantTo,
    int? NearDueFrom,
    int? NearDueTo,
    string? Overdue,
    bool IsBusinessDate,
    int StatusConcept,
    int? StartDateConcept,
    int? EndDateConcept);

public interface IDashboardConfigurationRepository
{
    Task<IReadOnlyList<ConfigRow>> LoadActiveConfigurationAsync(CancellationToken cancellationToken);
    Task<IReadOnlyList<ProgramDurationRow>> LoadProgramDurationRulesAsync(CancellationToken cancellationToken);
    Task<string?> GetJwtSigningKeyAsync(string issuer, CancellationToken cancellationToken);
}