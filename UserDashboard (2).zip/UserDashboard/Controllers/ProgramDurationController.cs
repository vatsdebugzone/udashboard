using Microsoft.AspNetCore.Mvc;
using UserDashboard.BusinessAccessLayer;

namespace UserDashboard.Controllers
{
    public class ProgramDurationController : Controller
    {
        private readonly IProgramDurationService _programDurationService;

        public ProgramDurationController(IProgramDurationService programDurationService)
        {
            _programDurationService = programDurationService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ProgramDuration(string? member)
        {
            ViewData["SelectedMember"] = member;
            return View();
        }

        [HttpGet]
        public JsonResult GetProgramDurationChartData()
        {
            var data = _programDurationService.GetChartData();
            return Json(new
            {
                teamName = data.FirstOrDefault()?.TeamName ?? "Team",
                labels = data.Select(item => item.MemberName).ToList(),
                overdue = data.Select(item => item.Overdue).ToList(),
                nearingDue = data.Select(item => item.NearingDue).ToList(),
                compliant = data.Select(item => item.Compliant).ToList()
            });
        }

        [HttpGet]
        public JsonResult GetProgramDurationTableData(string? member)
        {
            return Json(_programDurationService.GetDetailData(member));
        }
    }
}
