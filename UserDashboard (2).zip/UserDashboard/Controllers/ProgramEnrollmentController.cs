using Microsoft.AspNetCore.Mvc;
using UserDashboard.BusinessAccessLayer;

namespace UserDashboard.Controllers
{
    public class ProgramEnrollmentController : Controller
    {
        private readonly IProgramEnrollmentService _programEnrollmentService;

        public ProgramEnrollmentController(IProgramEnrollmentService programEnrollmentService)
        {
            _programEnrollmentService = programEnrollmentService;
        }

        public IActionResult Index()
        {
            var model = _programEnrollmentService.GetEnrollmentData();
            return View(model);
        }

        public IActionResult ProgramEnrollment()
        {
            var model = _programEnrollmentService.GetEnrollmentData();
            return View(model);
        }

        [HttpGet]
        public JsonResult GetProgramEnrollmentChartData()
        {
            var data = _programEnrollmentService.GetEnrollmentData();
            return Json(new
            {
                labels = data.Select(x => x.Name).ToList(),
                values = data.Select(x => x.Count).ToList()
            });
        }

        [HttpGet]
        public JsonResult GetProgramEnrollmentTableData()
        {
            var rows = new[]
            {
                new { caseId = "CM0558174", caseName = "Star Plus", memberName = "Member's First/Last Name", programsAssigned = "CFC MNLOC, Age Out, Complex Case Management" },
                new { caseId = "CM0558053", caseName = "CCM", memberName = "Member's First/Last Name", programsAssigned = "Complex Case Management, Maternity Program" },
                new { caseId = "CM0558169", caseName = "CCM", memberName = "Member's First/Last Name", programsAssigned = "Complex Case Management, Pregnancy, Nutrition Counseling" },
                new { caseId = "CM0000028", caseName = "Disease Management Program", memberName = "Member's First/Last Name", programsAssigned = "Disease Case Management, AAPCA, Behavioral Health" },
                new { caseId = "CM0558222", caseName = "Dental Care", memberName = "Member's First/Last Name", programsAssigned = "Dental Health Services" },
                new { caseId = "CM0558301", caseName = "Care Coordination", memberName = "Member's First/Last Name", programsAssigned = "Care Coordination, Education Support" },
                new { caseId = "CM0558456", caseName = "Diabetes Support", memberName = "Member's First/Last Name", programsAssigned = "Nutrition Coaching, Diabetes Education" },
                new { caseId = "CM0558512", caseName = "Asthma Program", memberName = "Member's First/Last Name", programsAssigned = "Respiratory Management, Home Follow-Up" },
                new { caseId = "CM0558654", caseName = "Mental Health", memberName = "Member's First/Last Name", programsAssigned = "Counseling, Therapy Support" },
                new { caseId = "CM0558900", caseName = "Wellness Plan", memberName = "Member's First/Last Name", programsAssigned = "Fitness Coaching, Wellness Check" },
                new { caseId = "CM0559105", caseName = "Chronic Care", memberName = "Member's First/Last Name", programsAssigned = "Medication Review, Chronic Support" },
                new { caseId = "CM0559333", caseName = "Family Services", memberName = "Member's First/Last Name", programsAssigned = "Family Counseling, Housing Support" }
            };

            return Json(rows);
        }
    }
}
