using Microsoft.AspNetCore.Mvc;
using UserDashboard.BusinessAccessLayer;

namespace UserDashboard.Controllers
{
    public class ServiceCoordinationController : Controller
    {
        private readonly IServiceCoordinationService _serviceCoordinationService;

        public ServiceCoordinationController(IServiceCoordinationService serviceCoordinationService)
        {
            _serviceCoordinationService = serviceCoordinationService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult ServiceCoordination()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetServiceCoordinationChartData()
        {
            var data = _serviceCoordinationService.GetChartData();
            return Json(new
            {
                teamName = data.FirstOrDefault()?.TeamName ?? "Team",
                labels = data.Select(item => item.MemberName).ToList(),
                level1 = data.Select(item => item.Level1).ToList(),
                level2 = data.Select(item => item.Level2).ToList(),
                level3 = data.Select(item => item.Level3).ToList()
            });
        }

        [HttpGet]
        public JsonResult GetOverduePrograms()
        {
            return Json(_serviceCoordinationService.GetOverduePrograms());
        }
    }
}
