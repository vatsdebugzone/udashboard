using UserDashboard.BusinessAccessLayer;
using UserDashboard.DataAccessLayer;

namespace UserDashboard
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();
            builder.Services.AddScoped<IProgramEnrollmentRepository, ProgramEnrollmentRepository>();
            builder.Services.AddScoped<IProgramEnrollmentService, ProgramEnrollmentService>();
            builder.Services.AddScoped<IServiceCoordinationRepository, ServiceCoordinationRepository>();
            builder.Services.AddScoped<IServiceCoordinationService, ServiceCoordinationService>();
            builder.Services.AddScoped<IProgramDurationRepository, ProgramDurationRepository>();
            builder.Services.AddScoped<IProgramDurationService, ProgramDurationService>();

            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
