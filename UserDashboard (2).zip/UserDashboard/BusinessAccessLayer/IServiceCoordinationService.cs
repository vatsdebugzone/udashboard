using UserDashboard.Models;

namespace UserDashboard.BusinessAccessLayer
{
    public interface IServiceCoordinationService
    {
        List<ServiceCoordinationChartItem> GetChartData();
        List<ServiceCoordinationOverdueProgramItem> GetOverduePrograms();
    }
}