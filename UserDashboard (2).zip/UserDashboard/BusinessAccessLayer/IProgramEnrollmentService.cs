using UserDashboard.Models;

namespace UserDashboard.BusinessAccessLayer
{
    public interface IProgramEnrollmentService
    {
        List<ProgramEnrollmentItem> GetEnrollmentData();
    }
}
