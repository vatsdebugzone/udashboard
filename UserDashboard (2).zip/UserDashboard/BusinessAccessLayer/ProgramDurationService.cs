using UserDashboard.DataAccessLayer;
using UserDashboard.Models;

namespace UserDashboard.BusinessAccessLayer
{
    public class ProgramDurationService : IProgramDurationService
    {
        private readonly IProgramDurationRepository _repository;

        public ProgramDurationService(IProgramDurationRepository repository)
        {
            _repository = repository;
        }

        public List<ProgramDurationChartItem> GetChartData()
        {
            return _repository.GetChartData();
        }

        public List<ProgramDurationDetailItem> GetDetailData(string? memberName = null)
        {
            return _repository.GetDetailData(memberName);
        }
    }
}