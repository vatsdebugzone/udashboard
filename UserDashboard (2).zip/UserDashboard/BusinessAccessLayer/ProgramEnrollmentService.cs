using UserDashboard.DataAccessLayer;
using UserDashboard.Models;

namespace UserDashboard.BusinessAccessLayer
{
    public class ProgramEnrollmentService : IProgramEnrollmentService
    {
        private readonly IProgramEnrollmentRepository _repository;

        public ProgramEnrollmentService(IProgramEnrollmentRepository repository)
        {
            _repository = repository;
        }

        public List<ProgramEnrollmentItem> GetEnrollmentData()
        {
            return _repository.GetEnrollmentData();
        }
    }
}
