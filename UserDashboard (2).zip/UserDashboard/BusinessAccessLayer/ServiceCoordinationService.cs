using UserDashboard.DataAccessLayer;
using UserDashboard.Models;

namespace UserDashboard.BusinessAccessLayer
{
    public class ServiceCoordinationService : IServiceCoordinationService
    {
        private readonly IServiceCoordinationRepository _repository;

        public ServiceCoordinationService(IServiceCoordinationRepository repository)
        {
            _repository = repository;
        }

        public List<ServiceCoordinationChartItem> GetChartData()
        {
            return _repository.GetChartData();
        }

        public List<ServiceCoordinationOverdueProgramItem> GetOverduePrograms()
        {
            return _repository.GetOverduePrograms();
        }
    }
}