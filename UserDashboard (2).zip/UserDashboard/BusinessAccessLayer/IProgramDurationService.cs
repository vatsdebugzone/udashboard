using UserDashboard.Models;

namespace UserDashboard.BusinessAccessLayer
{
    public interface IProgramDurationService
    {
        List<ProgramDurationChartItem> GetChartData();
        List<ProgramDurationDetailItem> GetDetailData(string? memberName = null);
    }
}