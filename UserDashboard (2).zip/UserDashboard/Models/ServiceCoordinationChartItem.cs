namespace UserDashboard.Models
{
    public class ServiceCoordinationChartItem
    {
        public string MemberName { get; set; } = string.Empty;
        public string TeamName { get; set; } = string.Empty;
        public double Level1 { get; set; }
        public double Level2 { get; set; }
        public double Level3 { get; set; }
    }
}