namespace UserDashboard.Models
{
    public class ProgramDurationDetailItem
    {
        public string CaseId { get; set; } = string.Empty;
        public string CaseName { get; set; } = string.Empty;
        public string MemberName { get; set; } = string.Empty;
        public string ProgramsAssigned { get; set; } = string.Empty;
        public string ProgramsOverdue { get; set; } = string.Empty;
        public string DueDate { get; set; } = string.Empty;
    }
}