namespace UserDashboard.Models
{
    public class ServiceCoordinationOverdueProgramItem
    {
        public string CaseId { get; set; } = string.Empty;
        public string CaseName { get; set; } = string.Empty;
        public string MemberName { get; set; } = string.Empty;
        public string ScLevel { get; set; } = string.Empty;
        public string IspStartDate { get; set; } = string.Empty;
        public string IspEndDate { get; set; } = string.Empty;
        public string ProgramsAssigned { get; set; } = string.Empty;
        public string ProgramsOverdue { get; set; } = string.Empty;
        public string DueDate { get; set; } = string.Empty;
    }
}