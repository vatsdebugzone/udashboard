namespace UserDashboard.Models
{
    public class ProgramEnrollmentItem
    {
        public string Name { get; set; } = string.Empty;
        public int Count { get; set; }
    }
}
