namespace UserDashboard.Models
{
    public class ProgramDurationChartItem
    {
        public string MemberName { get; set; } = string.Empty;
        public string TeamName { get; set; } = string.Empty;
        public double Overdue { get; set; }
        public double NearingDue { get; set; }
        public double Compliant { get; set; }
    }
}