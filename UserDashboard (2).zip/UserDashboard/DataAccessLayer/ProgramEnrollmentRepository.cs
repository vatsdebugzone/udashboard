using UserDashboard.Models;

namespace UserDashboard.DataAccessLayer
{
    public class ProgramEnrollmentRepository : IProgramEnrollmentRepository
    {
        public List<ProgramEnrollmentItem> GetEnrollmentData()
        {
            return new List<ProgramEnrollmentItem>
            {
                new ProgramEnrollmentItem { Name = "Christi Wondrash", Count = 24 },
                new ProgramEnrollmentItem { Name = "Team Member 1", Count = 87 },
                new ProgramEnrollmentItem { Name = "Team Member 2", Count = 65 },
                new ProgramEnrollmentItem { Name = "Team Member 3", Count = 90 },
                new ProgramEnrollmentItem { Name = "Team Member 4", Count = 8 }
            };
        }
    }
}
