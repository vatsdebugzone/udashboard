using UserDashboard.Models;

namespace UserDashboard.DataAccessLayer
{
    public class ServiceCoordinationRepository : IServiceCoordinationRepository
    {
        public List<ServiceCoordinationChartItem> GetChartData()
        {
            return new List<ServiceCoordinationChartItem>
            {
                new() { MemberName = "Christi Wondrash", TeamName = "Team", Level1 = 36, Level2 = 23, Level3 = 41 },
                new() { MemberName = "Team Member 2", TeamName = "Team", Level1 = 42, Level2 = 21, Level3 = 37 },
                new() { MemberName = "Team Member 2", TeamName = "Team", Level1 = 28, Level2 = 49, Level3 = 23 },
                new() { MemberName = "Team Member", TeamName = "Team", Level1 = 50, Level2 = 27, Level3 = 23 }
            };
        }

        public List<ServiceCoordinationOverdueProgramItem> GetOverduePrograms()
        {
            return new List<ServiceCoordinationOverdueProgramItem>
            {
                new()
                {
                    CaseId = "CM0558174",
                    CaseName = "Star Plus",
                    MemberName = "Member's First/Last Name",
                    ScLevel = "Level 1",
                    IspStartDate = "01/30/2026",
                    IspEndDate = "04/30/2026",
                    ProgramsAssigned = "CFC MNLOC, Age Out, Complex Case Management",
                    ProgramsOverdue = "Age Out",
                    DueDate = "04/30/2026"
                },
                new()
                {
                    CaseId = "CM0558053",
                    CaseName = "CCM",
                    MemberName = "Member's First/Last Name",
                    ScLevel = "Level 2",
                    IspStartDate = "02/14/2026",
                    IspEndDate = "05/14/2026",
                    ProgramsAssigned = "Maternity Program",
                    ProgramsOverdue = "Maternity Program",
                    DueDate = "05/14/2026"
                },
                new()
                {
                    CaseId = "CM0558169",
                    CaseName = "CCM",
                    MemberName = "Member's First/Last Name",
                    ScLevel = "Level 2",
                    IspStartDate = "02/01/2026",
                    IspEndDate = "05/01/2026",
                    ProgramsAssigned = "Complex Case Management, Pregnancy, Nutrition Counseling",
                    ProgramsOverdue = "Complex Case Management",
                    DueDate = "05/01/2026"
                },
                new()
                {
                    CaseId = "CM0000028",
                    CaseName = "Disease Management Program",
                    MemberName = "Member's First/Last Name",
                    ScLevel = "Level 3",
                    IspStartDate = "12/30/2025",
                    IspEndDate = "03/30/2026",
                    ProgramsAssigned = "AAPCA, Behavioral Health",
                    ProgramsOverdue = "AAPCA",
                    DueDate = "03/30/2026"
                }
            };
        }
    }
}