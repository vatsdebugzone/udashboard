using UserDashboard.Models;

namespace UserDashboard.DataAccessLayer
{
    public class ProgramDurationRepository : IProgramDurationRepository
    {
        public List<ProgramDurationChartItem> GetChartData()
        {
            return new List<ProgramDurationChartItem>
            {
                new() { MemberName = "Christi Wondrash", TeamName = "Team", Overdue = 37, NearingDue = 23, Compliant = 40 },
                new() { MemberName = "Team Member 1", TeamName = "Team", Overdue = 42, NearingDue = 21, Compliant = 37 },
                new() { MemberName = "Team Member 2", TeamName = "Team", Overdue = 28, NearingDue = 49, Compliant = 23 },
                new() { MemberName = "Team Member", TeamName = "Team", Overdue = 50, NearingDue = 27, Compliant = 23 }
            };
        }

        public List<ProgramDurationDetailItem> GetDetailData(string? memberName = null)
        {
            var rows = new List<ProgramDurationDetailItem>
            {
                new() { CaseId = "CM0558174", CaseName = "Star Plus", MemberName = "Christi Wondrash", ProgramsAssigned = "CFC MNLOC, Age Out, Complex Case Management", ProgramsOverdue = "Age Out", DueDate = "04/30/2026" },
                new() { CaseId = "CM0558053", CaseName = "CCM", MemberName = "Christi Wondrash", ProgramsAssigned = "Maternity Program", ProgramsOverdue = "Maternity Program", DueDate = "05/14/2026" },
                new() { CaseId = "CM0558169", CaseName = "CCM", MemberName = "Christi Wondrash", ProgramsAssigned = "Complex Case Management, Pregnancy, Nutrition Counseling", ProgramsOverdue = "Complex Case Management", DueDate = "05/01/2026" },
                new() { CaseId = "CM0000028", CaseName = "Disease Management Program", MemberName = "Christi Wondrash", ProgramsAssigned = "Disease Case Management, AAPCA, Behavioral Health", ProgramsOverdue = "AAPCA", DueDate = "03/30/2026" },
                new() { CaseId = "CM0558222", CaseName = "Dental Care", MemberName = "Christi Wondrash", ProgramsAssigned = "Dental Health Services", ProgramsOverdue = "Dental Health Services", DueDate = "06/10/2026" },
                new() { CaseId = "CM0558301", CaseName = "Care Coordination", MemberName = "Team Member 1", ProgramsAssigned = "Care Coordination, Education Support", ProgramsOverdue = "Education Support", DueDate = "05/22/2026" },
                new() { CaseId = "CM0558456", CaseName = "Diabetes Support", MemberName = "Team Member 1", ProgramsAssigned = "Nutrition Coaching, Diabetes Education", ProgramsOverdue = "Diabetes Education", DueDate = "05/26/2026" },
                new() { CaseId = "CM0558512", CaseName = "Asthma Program", MemberName = "Team Member 1", ProgramsAssigned = "Respiratory Management, Home Follow-Up", ProgramsOverdue = "Home Follow-Up", DueDate = "06/02/2026" },
                new() { CaseId = "CM0558654", CaseName = "Mental Health", MemberName = "Team Member 2", ProgramsAssigned = "Counseling, Therapy Support", ProgramsOverdue = "Counseling", DueDate = "05/18/2026" },
                new() { CaseId = "CM0558900", CaseName = "Wellness Plan", MemberName = "Team Member 2", ProgramsAssigned = "Fitness Coaching, Wellness Check", ProgramsOverdue = "Wellness Check", DueDate = "05/29/2026" },
                new() { CaseId = "CM0559105", CaseName = "Chronic Care", MemberName = "Team Member", ProgramsAssigned = "Medication Review, Chronic Support", ProgramsOverdue = "Medication Review", DueDate = "06/05/2026" },
                new() { CaseId = "CM0559333", CaseName = "Family Services", MemberName = "Team Member", ProgramsAssigned = "Family Counseling, Housing Support", ProgramsOverdue = "Housing Support", DueDate = "06/12/2026" }
            };

            return string.IsNullOrWhiteSpace(memberName)
                ? rows
                : rows.Where(row => string.Equals(row.MemberName, memberName, StringComparison.OrdinalIgnoreCase)).ToList();
        }
    }
}