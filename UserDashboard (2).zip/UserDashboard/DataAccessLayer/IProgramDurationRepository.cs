using UserDashboard.Models;

namespace UserDashboard.DataAccessLayer
{
    public interface IProgramDurationRepository
    {
        List<ProgramDurationChartItem> GetChartData();
        List<ProgramDurationDetailItem> GetDetailData(string? memberName = null);
    }
}