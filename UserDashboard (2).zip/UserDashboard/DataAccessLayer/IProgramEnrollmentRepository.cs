using UserDashboard.Models;

namespace UserDashboard.DataAccessLayer
{
    public interface IProgramEnrollmentRepository
    {
        List<ProgramEnrollmentItem> GetEnrollmentData();
    }
}
