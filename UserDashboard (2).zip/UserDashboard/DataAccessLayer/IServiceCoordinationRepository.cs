using UserDashboard.Models;

namespace UserDashboard.DataAccessLayer
{
    public interface IServiceCoordinationRepository
    {
        List<ServiceCoordinationChartItem> GetChartData();
        List<ServiceCoordinationOverdueProgramItem> GetOverduePrograms();
    }
}